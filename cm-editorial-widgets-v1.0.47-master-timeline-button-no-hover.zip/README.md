CM Editorial Widgets v1.0.38

Timeline update: PRESENT and START black boxes now sit directly on the timeline line.

# CM Editorial Widgets v1.0.35

## New in v1.0.7

Social links now become thumbnail cards instead of plain embed players.

When you paste a TikTok link, the plugin tries to read the platform oEmbed data and use the video thumbnail above the button.

Example output:

[Thumbnail image]
Until It Sleeps — Watch on TikTok

The button opens the original social link.

## Notes

If TikTok does not provide a thumbnail for a specific short URL, the plugin still shows the button.

## Still included

- CM Laboratory Hero
- CM Featured News Grid
- Featured News no-hover layout
- Featured News fallback images
- Featured News right label URL
- Social short-link handling


## v1.0.8 - Fixed CM Link Bio

Built from the working v1.0.7 TikTok/social thumbnail buttons plugin.

Keeps:
- CM Laboratory Hero
- CM Featured News Grid
- TikTok/social thumbnail button listener

Adds/fixes:
- CM Link Bio widget in CM Widgets
- White background
- Black visible text
- Coloured link borders like the reference
- Pink/red icon colour defaults
- No phone bar
- No phone frame
- No grey link backgrounds
- Toggle profile/bio section on/off
- Toggle profile image on/off
- Toggle name, username, bio on/off
- Toggle links section on/off
- Toggle each individual link on/off


## v1.0.9 - CM Link Bio reference style

Built from the working TikTok/social listener plugin.

CM Link Bio changes:
- White background default
- Black text default
- Button colour controls
- Icon colour controls
- Coloured left icon block like the reference
- Matching coloured border
- No phone bar/time/battery
- No black phone background
- No grey link background
- Toggles for profile, image, name, username, bio, and links


## v1.0.10 - Link Bio white/reference colour fix

- Default white background forced.
- Default black text forced.
- No phone/time/battery styling.
- No black container.
- No grey link background.
- Reference link colours are forced by default:
  - Donate blue
  - Twitch purple
  - Discord blue/purple
  - Amazon orange
  - Merch pink
  - My Gear cyan
  - YouTube red
  - Twitter blue
  - Instagram pink
- Added Elementor toggle: Use Reference Link Colours.
  - ON = matches reference colours
  - OFF = use each link colour picker


## v1.0.11 - Link Bio defaults fix

- Profile image is OFF by default.
- Bio text is OFF by default.
- Icons are white by default.
- Link titles are lighter black text.
- Descriptions use normal black text weight.


## v1.0.12 - Link Bio profile defaults

- Profile name is OFF by default.
- @username/handle is OFF by default.
- Profile image remains OFF by default.
- Bio remains OFF by default.
- Merch default icon changed to T-shirt.


## v1.0.13 - Force Merch icon

- Merch now forces an inline white T-shirt SVG icon.
- This does not rely on FontAwesome loading the shirt/tshirt icon.


## v1.0.14 - Social listener Link Bio buttons

Classic editor social links now render using the same Link Bio button layout.

- Title uses platform name, e.g. TikTok.
- Description uses social metadata title/description where available.
- Fallback description uses nearby editor sentence text.
- Uses white background, black text, coloured icon block and border.


## v1.0.15 - Social listener button detection fix

- Classic editor social/non-affiliate links now render as Link Bio style buttons.
- Detects website/platform from the URL.
- Amazon and amzn.to links display as Amazon Finds.
- TikTok displays as TikTok.
- Description uses metadata title/description when available.
- Fallback uses nearby editor text.
- Old social card/thumb layout is hidden.


## v1.0.16 - Force social embeds into Link Bio buttons

- Adds a late the_content filter at priority 999.
- Forces TikTok blockquotes into Link Bio style buttons.
- Forces TikTok raw links into Link Bio style buttons.
- Forces Amazon/paypal/twitch/discord style links into Link Bio buttons.
- Hides old TikTok embed/card/thumb visuals.


## v1.0.17 - Link Bio auto logo colours

- Added Logo / Image Auto Colour field to each Link Bio item.
- When a logo is uploaded, the button border and left colour block automatically use the main colour from that logo.
- No ON/OFF toggle is needed; it is automatic by default.
- Existing manual colours still act as fallback if no logo is uploaded or colour extraction fails.


## v1.0.18 - Link Bio brand colours from title/icon

- Button colour now listens to the link title, URL, subtitle, and Elementor icon class.
- YouTube becomes red automatically.
- TikTok becomes cyan automatically.
- Twitch becomes purple automatically.
- Discord becomes blurple automatically.
- Amazon/Amazon Finds becomes orange automatically.
- PayPal/Donate becomes blue automatically.
- Instagram becomes pink automatically.
- Twitter/X becomes blue automatically.
- Merch/shirt/T-shirt becomes pink automatically.
- My Gear/gear/camera becomes cyan automatically.
- Uploaded logo colour still works as fallback when no known brand is detected.
- Manual colour remains the final fallback.


## v1.0.19 - Manual Link Bio colour wins

- Fixed Button Colour not changing when a brand title/icon was detected.
- If you manually change Button Colour to a custom colour, that colour now wins.
- Auto brand colours still work by default for YouTube, TikTok, Twitch, Discord, Amazon, PayPal, Instagram, Twitter/X, Merch, and My Gear.


## v1.0.20 - Button Colour field forced

- The Elementor field called Button Colour now always wins.
- Auto brand/icon colour only runs when Button Colour is empty.
- This fixes colour changes not showing on the front end.


## v1.0.21 - Typed hex Button Colour override

- Button Colour now accepts typed hex values with or without #.
- Supports 3-digit and 6-digit hex.
- Typed Button Colour overrides automatic brand/default colours.
- Auto brand colour only runs when Button Colour is empty or not a valid hex.


## v1.0.22 SAFE

Built from the working v1.0.21 baseline.

Kept:
- Link Bio
- Brand colour from title/icon
- Typed hex Button Colour override
- Social listener from the working baseline
- Visual icon block fix so the colour fills the left side/corners

Removed/not added:
- No multisite CPT Listen changes
- No new CPT selector code

This version is intended as the safe version after the fatal error.


## v1.0.24 - CPT Listen removed

This is the clean safe version.

Kept:
- Link Bio widget.
- Link Bio visual corner/icon block fix.
- Brand colours from title/icon.
- Typed hex Button Colour override.
- Social listener/TikTok functionality from the working baseline.
- Laboratory Hero.
- Featured News Grid.

Removed:
- All CPT Listen controls.
- All CPT Listen helper methods.
- All multisite CPT switching/listening code.


## Timeline per-item colours

Added per timeline item:
- Date Box Background
- Date Box Text Colour
- Item Line / Dot Colour
- Item Card Background

This lets each timeline date box be coloured separately like Link Bio link buttons.


## 1.0.29
- Timeline date is now rendered inside the content card above the title.


## Version 1.0.31
- Timeline now uses a V/notch connector instead of branch arms.
- Timeline line defaults to black.
- Timeline dots use a white outer dot with a black centre dot.
- Added title/body background colour control while keeping date background colour control.


## v1.0.31
- Timeline date/month header is now full edge-to-edge inside the content card.
- Default date/title background is black.
- V connector defaults to black.
- Bold timeline text reduced from chunky heavy weight to thin bold weight.


## Version 1.0.32
- Timeline title black background removed.
- Month/year date bar remains edge-to-edge with black default background.
- Title now sits on the white card background with thin bold weight.
- Black line, black V connector, and white dot with black centre retained.


## Version 1.0.33
- Added black PRESENT box to the top of the timeline line.
- Added black START box to the bottom of the timeline line.
- Kept existing black date bar, black V connector, white dot with black centre, and title background removed.


## v1.0.34
- Adjusted timeline Present and Start boxes on mobile so they have proper spacing like the reference layout and no longer sit clipped off the left edge.
- Kept black Present/Start boxes, black vertical line, black V connector, white outer dot and black centre dot.


## v1.0.35
- Fixed mobile PRESENT and START boxes so they have proper left/right space like the reference image.
- Moved mobile line/dots/card spacing together so the labels are centred over the line instead of being cut off.


## Version 1.0.37

- Centred the mobile timeline dots so the dot centre sits directly on the centre of the black vertical timeline line.
- Kept the existing present/start boxes, black line, black V connector, date header and card layout unchanged.


## v1.0.38 - Timeline auto grow

- Timeline height is now content-driven.
- Vertical line grows automatically when more timeline items or longer text are added.
- Removed fixed-height behaviour from timeline cards, body and description areas.
- Keeps the v1.0.37 centred dots, black line, PRESENT/START boxes, black V connector and date-only black header styling.


## Version 1.0.39
- Forces the CM Timeline widget to render on desktop, tablet, and mobile.
- Keeps the existing mobile timeline design, black line, centred dots, black V connectors, black month/year bar, START/PRESENT boxes, and auto-grow behaviour.


## Version 1.0.40
- Force CM Timeline to render on desktop, tablet and mobile.
- Added both underscore and hyphen Elementor widget selectors.
- Added late wp_head CSS override so Elementor responsive hidden classes cannot hide the timeline on desktop.
- Registered/enqueued the timeline stylesheet on normal front-end page loads as well as Elementor loads.
- Registered the Timeline widget independently from the Link Bio widget check.


## Version 1.0.41
- Fixes the critical error caused by missing desktop-force callback methods.
- Keeps the forced desktop/tablet/mobile timeline render CSS active.


## Version 1.0.43
- Added `Add New Items To Top` switch for the CM Timeline widget.
- Default is enabled, so newly added Elementor repeater items display at the top of the timeline automatically.
- Keeps existing desktop/mobile timeline layouts and all previous styling fixes.


## Version 1.0.44
- Timeline month and year now render on one single line, for example: March 2025.
- Keeps the existing black date bar, V connector, dots, START/PRESENT boxes, mobile layout and desktop layout unchanged.


## Version 1.0.46
- Centres the V connector vertically on the month/year date bar while keeping the existing timeline layout.


## Version 1.0.47
- Timeline card button now has no hover colour change.
- Button stays black with white text on default, hover, focus, active and visited states.
- Removes white hover background while keeping existing timeline layout unchanged.
