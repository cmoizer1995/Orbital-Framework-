<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! class_exists( 'CM_Timeline_Widget' ) ) :

class CM_Timeline_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'cm_timeline'; }
	public function get_title() { return esc_html__( 'CM Timeline', 'cm-editorial-widgets' ); }
	public function get_icon() { return 'eicon-time-line'; }
	public function get_categories() { return array( 'cm-editorial-widgets' ); }
	public function get_keywords() { return array( 'timeline', 'history', 'roadmap', 'milestones' ); }
	public function get_style_depends() { return array( 'cm-timeline-widget' ); }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array(
			'label' => esc_html__( 'Timeline', 'cm-editorial-widgets' ),
			'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		) );

		$this->add_control( 'desktop_layout', array(
			'label'   => esc_html__( 'Desktop Layout', 'cm-editorial-widgets' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'manual',
			'options' => array(
				'manual'    => esc_html__( 'Use Each Item Side', 'cm-editorial-widgets' ),
				'alternate' => esc_html__( 'Alternate Left / Right', 'cm-editorial-widgets' ),
			),
		) );


		$this->add_control( 'new_items_first', array(
			'label'        => esc_html__( 'Add New Items To Top', 'cm-editorial-widgets' ),
			'description'  => esc_html__( 'When enabled, Elementor still adds the new repeater row at the bottom in the editor, but the timeline displays newest added items at the top automatically so you do not need to manually drag them up.', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Yes', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'No', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => 'yes',
		) );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control( 'item_side', array(
			'label'   => esc_html__( 'Desktop Side', 'cm-editorial-widgets' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'right',
			'options' => array(
				'left'  => esc_html__( 'Left', 'cm-editorial-widgets' ),
				'right' => esc_html__( 'Right', 'cm-editorial-widgets' ),
			),
		) );

		$repeater->add_control( 'month', array(
			'label'       => esc_html__( 'Month / Small Date', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => esc_html__( 'March', 'cm-editorial-widgets' ),
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'year', array(
			'label'       => esc_html__( 'Year', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => esc_html__( '2025', 'cm-editorial-widgets' ),
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'title', array(
			'label'       => esc_html__( 'Title', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXTAREA,
			'default'     => esc_html__( 'Lorem Ipsum Dolor Sit Amet', 'cm-editorial-widgets' ),
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'description', array(
			'label'       => esc_html__( 'Description', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::WYSIWYG,
			'default'     => esc_html__( 'Add your timeline text here.', 'cm-editorial-widgets' ),
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'button_text', array(
			'label'       => esc_html__( 'Button Text', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => '',
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'button_url', array(
			'label'       => esc_html__( 'Button URL', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::URL,
			'default'     => array( 'url' => '' ),
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$this->add_control( 'items', array(
			'label'       => esc_html__( 'Timeline Items', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'title_field' => '{{{ year }}} - {{{ title }}}',
			'default'     => array(
				array(
					'item_side'   => 'right',
					'month'       => 'March',
					'year'        => '2025',
					'title'       => 'Lorem Ipsum Dolor Sit Amet',
					'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
				),
				array(
					'item_side'   => 'left',
					'month'       => 'March',
					'year'        => '2025',
					'title'       => 'Consectetur Adipiscing Elit',
					'description' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
				),
			),
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array(
			'label' => esc_html__( 'Timeline Style', 'cm-editorial-widgets' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$global_colour = array(
			'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY,
		);

		$this->add_control( 'line_colour', array(
			'label'     => esc_html__( 'Line Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#000000',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__track:before, {{WRAPPER}} .cm-timeline__dot:after' => 'background: {{VALUE}};',
			),
		) );

		$this->add_control( 'card_background', array(
			'label'     => esc_html__( 'Card Background', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#ffffff',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__card' => 'background: {{VALUE}};',
			),
		) );

		$this->add_control( 'date_colour', array(
			'label'     => esc_html__( 'Date Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#111111',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__date, {{WRAPPER}} .cm-timeline__date span, {{WRAPPER}} .cm-timeline__date strong' => 'color: {{VALUE}};',
			),
		) );

		$this->add_control( 'title_colour', array(
			'label'     => esc_html__( 'Title Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#111111',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__title' => 'color: {{VALUE}};',
			),
		) );

		$this->add_control( 'text_colour', array(
			'label'     => esc_html__( 'Text Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#222222',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__description' => 'color: {{VALUE}};',
			),
		) );

		$this->add_control( 'date_box_background', array(
			'label'     => esc_html__( 'Date Box Background', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#000000',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__date' => 'background: {{VALUE}};',
			),
		) );

		$this->add_control( 'date_box_text_colour', array(
			'label'     => esc_html__( 'Date Box Text Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#ffffff',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__date, {{WRAPPER}} .cm-timeline__date span, {{WRAPPER}} .cm-timeline__date strong' => 'color: {{VALUE}};',
			),
		) );



		$this->add_control( 'item_line_colour', array(
			'label'     => esc_html__( 'Item Line / Dot Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#000000',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__track:before, {{WRAPPER}} .cm-timeline__dot:after' => 'background: {{VALUE}};',
			),
		) );

		$this->add_control( 'item_card_background', array(
			'label'     => esc_html__( 'Item Card Background', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'global'    => $global_colour,
			'default'   => '#ffffff',
			'selectors' => array(
				'{{WRAPPER}} .cm-timeline__card' => 'background: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'card_padding', array(
			'label'      => esc_html__( 'Card Padding', 'cm-editorial-widgets' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px' ),
			'default'    => array(
				'top' => 24, 'right' => 24, 'bottom' => 24, 'left' => 24, 'unit' => 'px', 'isLinked' => true,
			),
			'selectors'  => array(
				'{{WRAPPER}} .cm-timeline__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->end_controls_section();
	}

	private function link_attrs( $url ) {
		if ( empty( $url['url'] ) ) { return ''; }
		$attrs = 'href="' . esc_url( $url['url'] ) . '"';
		if ( ! empty( $url['is_external'] ) ) { $attrs .= ' target="_blank"'; }
		if ( ! empty( $url['nofollow'] ) ) { $attrs .= ' rel="nofollow"'; }
		return $attrs;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$layout   = ! empty( $settings['desktop_layout'] ) ? $settings['desktop_layout'] : 'manual';
		$items    = ! empty( $settings['items'] ) && is_array( $settings['items'] ) ? $settings['items'] : array();

		if ( ! empty( $settings['new_items_first'] ) && 'yes' === $settings['new_items_first'] ) {
			$items = array_reverse( $items );
		}
		?>
		<section class="cm-timeline">
			<div class="cm-timeline__track cm-timeline__track--<?php echo esc_attr( $layout ); ?>">
				<span class="cm-timeline__label cm-timeline__label--present" aria-hidden="true">Present</span>
				<?php foreach ( (array) $items as $index => $item ) : ?>
					<?php
					$side = ! empty( $item['item_side'] ) ? $item['item_side'] : 'right';
					if ( 'alternate' === $layout ) { $side = ( 0 === $index % 2 ) ? 'right' : 'left'; }
					$attrs = $this->link_attrs( isset( $item['button_url'] ) ? $item['button_url'] : array() );
					?>
					<article class="cm-timeline__item cm-timeline__item--<?php echo esc_attr( $side ); ?>">
						<span class="cm-timeline__dot" aria-hidden="true"></span>
						<div class="cm-timeline__card">
							<?php if ( ! empty( $item['month'] ) || ! empty( $item['year'] ) ) : ?>
								<div class="cm-timeline__date">
									<span class="cm-timeline__date-line">
										<?php if ( ! empty( $item['month'] ) ) : ?><span class="cm-timeline__month"><?php echo esc_html( $item['month'] ); ?></span><?php endif; ?>
										<?php if ( ! empty( $item['year'] ) ) : ?><strong class="cm-timeline__year"><?php echo esc_html( $item['year'] ); ?></strong><?php endif; ?>
									</span>
								</div>
							<?php endif; ?>
							<div class="cm-timeline__body">
								<?php if ( ! empty( $item['title'] ) ) : ?><h3 class="cm-timeline__title"><?php echo esc_html( $item['title'] ); ?></h3><?php endif; ?>
								<?php if ( ! empty( $item['description'] ) ) : ?><div class="cm-timeline__description"><?php echo wp_kses_post( $item['description'] ); ?></div><?php endif; ?>
								<?php if ( ! empty( $item['button_text'] ) && ! empty( $attrs ) ) : ?><a class="cm-timeline__button" <?php echo $attrs; ?>><?php echo esc_html( $item['button_text'] ); ?></a><?php endif; ?>
							</div>
						</div>
					</article>
				<?php endforeach; ?>
				<span class="cm-timeline__label cm-timeline__label--start" aria-hidden="true">Start</span>
			</div>
		</section>
		<?php
	}
}

endif;
