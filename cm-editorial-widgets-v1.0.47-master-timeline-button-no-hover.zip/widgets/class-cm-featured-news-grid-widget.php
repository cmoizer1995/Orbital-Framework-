<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CM_Featured_News_Grid_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'cm_featured_news_grid'; }
	public function get_title() { return 'CM Featured News Grid'; }
	public function get_icon() { return 'eicon-posts-grid'; }
	public function get_categories() { return array( 'cm-editorial-widgets' ); }
	public function get_style_depends() { return array( 'cm-featured-news-grid' ); }

	private function get_known_post_types() {
		$out = array();
		foreach ( get_post_types( array(), 'objects' ) as $slug => $obj ) {
			if ( 'attachment' === $slug ) continue;
			if ( ! empty( $obj->public ) || ! empty( $obj->publicly_queryable ) || ! empty( $obj->show_ui ) ) {
				$out[ $slug ] = $obj;
			}
		}

		$cptui = get_option( 'cptui_post_types', array() );
		if ( is_array( $cptui ) ) {
			foreach ( $cptui as $slug => $data ) {
				$real = ! empty( $data['name'] ) ? sanitize_key( $data['name'] ) : sanitize_key( $slug );
				if ( $real && ! isset( $out[ $real ] ) ) {
					$label = ! empty( $data['label'] ) ? $data['label'] : $real;
					$obj = new stdClass();
					$obj->labels = (object) array(
						'name' => $label,
						'singular_name' => ! empty( $data['singular_label'] ) ? $data['singular_label'] : $label,
					);
					$out[ $real ] = $obj;
				}
			}
		}
		return $out;
	}

	private function cpt_options() {
		$options = array();
		if ( is_multisite() && function_exists( 'get_sites' ) ) {
			foreach ( get_sites( array( 'number' => 500 ) ) as $site ) {
				switch_to_blog( (int) $site->blog_id );
				$details = get_blog_details( $site->blog_id );
				$site_name = $details && ! empty( $details->blogname ) ? $details->blogname : 'Site ' . $site->blog_id;
				foreach ( $this->get_known_post_types() as $type => $obj ) {
					$label = isset( $obj->labels->singular_name ) ? $obj->labels->singular_name : $type;
					$options[ (int) $site->blog_id . '|' . $type ] = $site_name . ' → ' . $label . ' — ' . $type;
				}
				restore_current_blog();
			}
		} else {
			foreach ( $this->get_known_post_types() as $type => $obj ) {
				$label = isset( $obj->labels->singular_name ) ? $obj->labels->singular_name : $type;
				$options[ 'current|' . $type ] = $label . ' — ' . $type;
			}
		}
		if ( empty( $options ) ) $options['current|post'] = 'Posts — post';
		return $options;
	}

	private function content_options() {
		$options = array( '' => 'Auto newest from selected CPTs' );
		if ( is_multisite() && function_exists( 'get_sites' ) ) {
			foreach ( get_sites( array( 'number' => 500 ) ) as $site ) {
				switch_to_blog( (int) $site->blog_id );
				$details = get_blog_details( $site->blog_id );
				$site_name = $details && ! empty( $details->blogname ) ? $details->blogname : 'Site ' . $site->blog_id;
				foreach ( $this->get_known_post_types() as $type => $obj ) {
					$label = isset( $obj->labels->singular_name ) ? $obj->labels->singular_name : $type;
					$posts = get_posts( array( 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 50, 'orderby' => 'date', 'order' => 'DESC' ) );
					foreach ( $posts as $p ) {
						$options[ (int) $site->blog_id . '|' . $type . '|' . (int) $p->ID ] = $site_name . ' → ' . $label . ' → ' . get_the_title( $p );
					}
				}
				restore_current_blog();
			}
		} else {
			foreach ( $this->get_known_post_types() as $type => $obj ) {
				$label = isset( $obj->labels->singular_name ) ? $obj->labels->singular_name : $type;
				$posts = get_posts( array( 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 100, 'orderby' => 'date', 'order' => 'DESC' ) );
				foreach ( $posts as $p ) {
					$options[ 'current|' . $type . '|' . (int) $p->ID ] = $label . ' → ' . get_the_title( $p );
				}
			}
		}
		return $options;
	}

	protected function register_controls() {
		$cpt_options = $this->cpt_options();
		$content_options = $this->content_options();

		$this->start_controls_section( 'heading_section', array( 'label' => 'Header' ) );
		$this->add_control( 'heading', array( 'label' => 'Heading', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Featured News' ) );
		$this->add_control( 'right_label', array( 'label' => 'Right Label', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Recently Published' ) );

		$this->add_control( 'right_label_url', array(
			'label' => 'Right Label URL',
			'type' => \Elementor\Controls_Manager::URL,
			'default' => array( 'url' => '#' ),
			'placeholder' => 'https://example.com/news/',
		) );

		$this->add_control( 'right_label_new_tab', array(
			'label' => 'Open Right Label In New Tab',
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'label_on' => 'Yes',
			'label_off' => 'No',
			'return_value' => 'yes',
			'default' => '',
		) );

		$this->add_control( 'show_right_dot', array(
			'label' => 'Show Red Dot',
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'label_on' => 'Show',
			'label_off' => 'Hide',
			'return_value' => 'yes',
			'default' => 'yes',
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'source_section', array( 'label' => 'CPT Source Controls' ) );
		$this->add_control( 'source_notice', array(
			'type' => \Elementor\Controls_Manager::RAW_HTML,
			'raw' => 'Select the CPTs once here. The newest 4 items fill the big square cards first, then the next newest items fill the circle row.',
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
		) );
		$this->add_control( 'global_cpts', array(
			'label' => 'Select Site + CPTs',
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => $cpt_options,
			'default' => array( array_key_first( $cpt_options ) ),
			'multiple' => true,
			'label_block' => true,
		) );
		$this->add_control( 'global_listing_url', array(
			'label' => 'URL Listing Listener',
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => '',
			'placeholder' => 'https://connormoizer.com/portfolio/web/nova-login/',
			'label_block' => true,
		) );
		$this->add_control( 'global_slug_override', array(
			'label' => 'CPT Slug Override',
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => '',
			'placeholder' => 'blog,work,reviews,testimonials',
			'description' => 'Comma-separated CPT slugs. This is useful if CPT UI types do not show in the list.',
			'label_block' => true,
		) );
		$this->add_control( 'total_posts', array(
			'label' => 'Total Items To Pull',
			'type' => \Elementor\Controls_Manager::NUMBER,
			'default' => 8,
			'min' => 4,
			'max' => 20,
		) );

		$this->add_control( 'global_fallback_image', array(
			'label' => 'Global Fallback Image',
			'type' => \Elementor\Controls_Manager::MEDIA,
			'description' => 'Used when a post/card has no featured image or override image.',
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'override_section', array( 'label' => 'Optional Card Overrides' ) );
		for ( $i = 1; $i <= 8; $i++ ) {
			$this->add_control( "card_{$i}_heading", array( 'label' => "Card {$i}", 'type' => \Elementor\Controls_Manager::HEADING, 'separator' => $i === 1 ? 'none' : 'before' ) );
			$this->add_control( "card_{$i}_content", array(
				'label' => 'Force Exact Content',
				'type' => \Elementor\Controls_Manager::SELECT2,
				'options' => $content_options,
				'default' => '',
				'label_block' => true,
			) );

			$this->add_control( "card_{$i}_image_override", array(
				'label' => 'Override Image',
				'type' => \Elementor\Controls_Manager::MEDIA,
			) );

			$this->add_control( "card_{$i}_use_featured_image", array(
				'label' => 'Use Featured Image',
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => 'Yes',
				'label_off' => 'No',
				'return_value' => 'yes',
				'default' => 'yes',
			) );

			$this->add_control( "card_{$i}_use_global_fallback", array(
				'label' => 'Fallback To Global Image',
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => 'Yes',
				'label_off' => 'No',
				'return_value' => 'yes',
				'default' => 'yes',
			) );

			$this->add_control( "card_{$i}_label", array( 'label' => 'Small Label Override', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '', 'placeholder' => 'BLOG' ) );
			$this->add_control( "card_{$i}_read", array( 'label' => 'Read Time Override', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '', 'placeholder' => '3 MIN READ' ) );
		}
		$this->end_controls_section();

		$this->start_controls_section( 'style_section', array( 'label' => 'Layout / Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'section_padding', array(
			'label' => 'Section Padding',
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px' ),
			'default' => array( 'top' => 70, 'right' => 10, 'bottom' => 60, 'left' => 10, 'unit' => 'px', 'isLinked' => false ),
			'selectors' => array( '{{WRAPPER}} .cm-featured-news' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_control( 'background_colour', array(
			'label' => 'Background Colour',
			'type' => \Elementor\Controls_Manager::COLOR,
			'default' => '#f4f1e8',
			'selectors' => array( '{{WRAPPER}} .cm-featured-news' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_control( 'text_colour', array(
			'label' => 'Text Colour',
			'type' => \Elementor\Controls_Manager::COLOR,
			'default' => '#1f1f1f',
			'selectors' => array( '{{WRAPPER}} .cm-featured-news, {{WRAPPER}} .cm-featured-news a' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_section();
	}

	private function split_value( $value ) {
		$parts = explode( '|', (string) $value );
		return array(
			'site' => isset( $parts[0] ) ? $parts[0] : 'current',
			'type' => isset( $parts[1] ) ? sanitize_key( $parts[1] ) : 'post',
			'id' => isset( $parts[2] ) ? absint( $parts[2] ) : 0,
		);
	}

	private function selected_to_groups( $selected, $slug_override = '', $listing_url = '' ) {
		$groups = array();

		if ( ! empty( $selected ) ) {
			foreach ( (array) $selected as $item ) {
				$v = $this->split_value( $item );
				$site = ! empty( $v['site'] ) ? $v['site'] : 'current';
				$type = ! empty( $v['type'] ) ? $v['type'] : 'post';
				$groups[ $site ][] = $type;
			}
		}

		if ( ! empty( $slug_override ) ) {
			$site = 'current';
			if ( ! empty( $selected[0] ) ) {
				$first = $this->split_value( $selected[0] );
				$site = $first['site'];
			}
			$groups[ $site ] = array_map( 'sanitize_key', array_map( 'trim', explode( ',', $slug_override ) ) );
		}

		if ( ! empty( $listing_url ) ) {
			$type = $this->infer_cpt_from_url( $listing_url );
			if ( $type ) $groups['current'][] = $type;
		}

		return $groups;
	}

	private function infer_cpt_from_url( $url ) {
		$path = trim( wp_parse_url( esc_url_raw( $url ), PHP_URL_PATH ), '/' );
		if ( ! $path ) return '';
		$parts = explode( '/', $path );
		$known = array_keys( $this->get_known_post_types() );
		foreach ( $parts as $part ) {
			$key = sanitize_key( $part );
			if ( in_array( $key, $known, true ) ) return $key;
		}
		return count( $parts ) >= 2 ? sanitize_key( $parts[ count( $parts ) - 2 ] ) : '';
	}

	private function post_data( $post ) {
		$obj = get_post_type_object( get_post_type( $post ) );
		$label = $obj && isset( $obj->labels->singular_name ) ? $obj->labels->singular_name : get_post_type( $post );
		return array(
			'title' => get_the_title( $post ),
			'url' => get_permalink( $post ),
			'image' => get_the_post_thumbnail_url( $post, 'large' ),
			'label' => strtoupper( $label ),
			'read' => '3 MIN READ',
			'date' => (int) get_post_time( 'U', true, $post ),
		);
	}

	private function newest_from_groups( $groups, $limit = 8 ) {
		$items = array();

		foreach ( $groups as $site => $types ) {
			$types = array_filter( array_unique( array_map( 'sanitize_key', (array) $types ) ) );
			if ( empty( $types ) ) continue;

			$switched = false;
			if ( is_multisite() && 'current' !== $site ) {
				$site_id = absint( $site );
				if ( $site_id && get_current_blog_id() !== $site_id ) {
					switch_to_blog( $site_id );
					$switched = true;
				}
			}

			$q = new \WP_Query( array(
				'post_type' => $types,
				'post_status' => 'publish',
				'posts_per_page' => max( 1, $limit ),
				'orderby' => 'date',
				'order' => 'DESC',
				'ignore_sticky_posts' => true,
				'no_found_rows' => true,
			) );

			foreach ( $q->posts as $p ) $items[] = $this->post_data( $p );

			wp_reset_postdata();
			if ( $switched ) restore_current_blog();
		}

		usort( $items, function( $a, $b ) { return $b['date'] <=> $a['date']; } );
		return array_slice( $items, 0, absint( $limit ) );
	}

	private function exact_card( $value ) {
		if ( empty( $value ) ) return null;
		$v = $this->split_value( $value );
		$switched = false;

		if ( is_multisite() && 'current' !== $v['site'] ) {
			$site_id = absint( $v['site'] );
			if ( $site_id && get_current_blog_id() !== $site_id ) {
				switch_to_blog( $site_id );
				$switched = true;
			}
		}

		$post = ! empty( $v['id'] ) ? get_post( $v['id'] ) : null;
		$data = ( $post && 'publish' === $post->post_status ) ? $this->post_data( $post ) : null;

		if ( $switched ) restore_current_blog();
		return $data;
	}

	private function apply_overrides( $card, $settings, $index ) {
		if ( ! $card ) return $card;

		$override_image = ! empty( $settings[ "card_{$index}_image_override" ]['url'] ) ? $settings[ "card_{$index}_image_override" ]['url'] : '';
		$global_fallback = ! empty( $settings['global_fallback_image']['url'] ) ? $settings['global_fallback_image']['url'] : '';
		$use_featured = ! isset( $settings[ "card_{$index}_use_featured_image" ] ) || 'yes' === $settings[ "card_{$index}_use_featured_image" ];
		$use_global = ! isset( $settings[ "card_{$index}_use_global_fallback" ] ) || 'yes' === $settings[ "card_{$index}_use_global_fallback" ];

		if ( $override_image ) {
			$card['image'] = $override_image;
		} elseif ( ! $use_featured ) {
			$card['image'] = $use_global ? $global_fallback : '';
		} elseif ( empty( $card['image'] ) && $use_global ) {
			$card['image'] = $global_fallback;
		}

		if ( ! empty( $settings[ "card_{$index}_label" ] ) ) $card['label'] = $settings[ "card_{$index}_label" ];
		if ( ! empty( $settings[ "card_{$index}_read" ] ) ) $card['read'] = $settings[ "card_{$index}_read" ];
		return $card;
	}

	private function render_big_card( $card, $class = '' ) {
		if ( ! $card ) return;
		$style = ! empty( $card['image'] ) ? ' style="background-image:url(' . esc_url( $card['image'] ) . ');"' : '';
		?>
		<a class="cm-featured-news__card <?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( $card['url'] ); ?>"<?php echo $style; ?>>
			<span class="cm-featured-news__shade"></span>
			<span class="cm-featured-news__type"><?php echo esc_html( $card['label'] ); ?></span>
			<span class="cm-featured-news__card-content">
				<span class="cm-featured-news__read"><?php echo esc_html( $card['read'] ); ?></span>
				<span class="cm-featured-news__title"><?php echo esc_html( $card['title'] ); ?></span>
			</span>
		</a>
		<?php
	}

	private function render_circle_card( $card ) {
		if ( ! $card ) return;
		$style = ! empty( $card['image'] ) ? ' style="background-image:url(' . esc_url( $card['image'] ) . ');"' : '';
		?>
		<a class="cm-featured-news__mini" href="<?php echo esc_url( $card['url'] ); ?>">
			<span class="cm-featured-news__mini-image"<?php echo $style; ?>></span>
			<span class="cm-featured-news__mini-text">
				<span class="cm-featured-news__mini-read"><?php echo esc_html( $card['read'] ); ?></span>
				<span class="cm-featured-news__mini-title"><?php echo esc_html( $card['title'] ); ?></span>
				<span class="cm-featured-news__mini-type"><?php echo esc_html( $card['label'] ); ?></span>
			</span>
		</a>
		<?php
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$groups = $this->selected_to_groups( $s['global_cpts'] ?? array(), $s['global_slug_override'] ?? '', $s['global_listing_url'] ?? '' );
		$items = $this->newest_from_groups( $groups, absint( $s['total_posts'] ?? 8 ) );

		for ( $i = 1; $i <= 8; $i++ ) {
			if ( ! empty( $s[ "card_{$i}_content" ] ) ) {
				$exact = $this->exact_card( $s[ "card_{$i}_content" ] );
				if ( $exact ) $items[ $i - 1 ] = $exact;
			}
			if ( isset( $items[ $i - 1 ] ) ) {
				$items[ $i - 1 ] = $this->apply_overrides( $items[ $i - 1 ], $s, $i );
			}
		}
		?>
		<section class="cm-featured-news">
			<div class="cm-featured-news__inner">
				<div class="cm-featured-news__header">
					<h2><?php echo esc_html( $s['heading'] ?? 'Featured News' ); ?></h2>
					<?php
					$right_url = ! empty( $s['right_label_url']['url'] ) ? $s['right_label_url']['url'] : '#';
					$right_target = ! empty( $s['right_label_new_tab'] ) && 'yes' === $s['right_label_new_tab'] ? ' target="_blank" rel="noopener noreferrer"' : '';
					$show_dot = ! empty( $s['show_right_dot'] ) && 'yes' === $s['show_right_dot'];
					?>
					<a class="cm-featured-news__right-label" href="<?php echo esc_url( $right_url ); ?>"<?php echo $right_target; ?>>
						<?php echo esc_html( $s['right_label'] ?? 'Recently Published' ); ?>
						<?php if ( $show_dot ) : ?><span>●</span><?php endif; ?>
					</a>
				</div>

				<div class="cm-featured-news__grid">
					<div class="cm-featured-news__main"><?php $this->render_big_card( $items[0] ?? null, 'cm-featured-news__card--large' ); ?></div>
					<div class="cm-featured-news__middle"><?php $this->render_big_card( $items[1] ?? null, 'cm-featured-news__card--tall' ); ?></div>
					<div class="cm-featured-news__side">
						<?php $this->render_big_card( $items[2] ?? null, 'cm-featured-news__card--small' ); ?>
						<?php $this->render_big_card( $items[3] ?? null, 'cm-featured-news__card--small' ); ?>
					</div>
				</div>

				<div class="cm-featured-news__minis">
					<?php for ( $i = 4; $i <= 7; $i++ ) $this->render_circle_card( $items[ $i ] ?? null ); ?>
				</div>
			</div>
		</section>
		<?php
	}
}
