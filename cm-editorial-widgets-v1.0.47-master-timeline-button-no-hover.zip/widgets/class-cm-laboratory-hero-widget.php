<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CM_Laboratory_Hero_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'cm_laboratory_hero';
	}

	public function get_title() {
		return esc_html__( 'CM Laboratory Hero', 'cm-laboratory-hero-widget' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_categories() { return array( 'cm-editorial-widgets' ); }

	public function get_keywords() {
		return array( 'hero', 'banner', 'laboratory', 'mission', 'space', 'header', 'cpt', 'portfolio', 'multisite', 'cpt ui' );
	}

	public function get_style_depends() {
		return array( 'cm-laboratory-hero-widget' );
	}

	private function get_site_options_for_control() {
		$options = array(
			'current' => esc_html__( 'Current Site', 'cm-laboratory-hero-widget' ),
		);

		if ( is_multisite() && function_exists( 'get_sites' ) ) {
			$sites = get_sites( array( 'number' => 500 ) );

			foreach ( $sites as $site ) {
				$details = get_blog_details( $site->blog_id );
				$name    = $details && ! empty( $details->blogname ) ? $details->blogname : 'Site ' . $site->blog_id;

				$options[ (string) $site->blog_id ] = $name . ' — ' . $site->domain . $site->path;
			}
		}

		return $options;
	}

	private function get_all_known_post_type_slugs() {
		$slugs = array();

		$registered = get_post_types( array(), 'objects' );

		foreach ( $registered as $slug => $object ) {
			if ( 'attachment' === $slug ) {
				continue;
			}

			$is_public = ! empty( $object->public ) || ! empty( $object->publicly_queryable ) || ! empty( $object->show_ui );

			if ( $is_public ) {
				$slugs[ $slug ] = $object;
			}
		}

		$cptui_types = get_option( 'cptui_post_types', array() );

		if ( is_array( $cptui_types ) ) {
			foreach ( $cptui_types as $slug => $data ) {
				if ( is_array( $data ) ) {
					$real_slug = ! empty( $data['name'] ) ? sanitize_key( $data['name'] ) : sanitize_key( $slug );

					if ( $real_slug && ! isset( $slugs[ $real_slug ] ) ) {
						$label = ! empty( $data['label'] ) ? $data['label'] : $real_slug;

						$obj = new stdClass();
						$obj->name = $real_slug;
						$obj->label = $label;
						$obj->labels = (object) array(
							'name'          => $label,
							'singular_name' => ! empty( $data['singular_label'] ) ? $data['singular_label'] : $label,
						);
						$obj->public = true;
						$obj->publicly_queryable = true;
						$obj->show_ui = true;

						$slugs[ $real_slug ] = $obj;
					}
				}
			}
		}

		return $slugs;
	}

	private function get_cpt_options_for_control() {
		$options = array();

		if ( is_multisite() && function_exists( 'get_sites' ) ) {
			$sites = get_sites( array( 'number' => 500 ) );

			foreach ( $sites as $site ) {
				switch_to_blog( (int) $site->blog_id );

				$details   = get_blog_details( $site->blog_id );
				$site_name = $details && ! empty( $details->blogname ) ? $details->blogname : 'Site ' . $site->blog_id;

				$post_types = $this->get_all_known_post_type_slugs();

				foreach ( $post_types as $post_type => $object ) {
					$label = isset( $object->labels->singular_name ) ? $object->labels->singular_name : $post_type;
					$key = (int) $site->blog_id . '|' . $post_type;
					$options[ $key ] = $site_name . ' → ' . $label . ' — ' . $post_type;
				}

				restore_current_blog();
			}
		} else {
			$post_types = $this->get_all_known_post_type_slugs();

			foreach ( $post_types as $post_type => $object ) {
				$label = isset( $object->labels->singular_name ) ? $object->labels->singular_name : $post_type;
				$options[ 'current|' . $post_type ] = $label . ' — ' . $post_type;
			}
		}

		if ( empty( $options ) ) {
			$options['current|post'] = 'Posts — post';
		}

		return $options;
	}

	private function get_content_options_for_control() {
		$options = array(
			'' => esc_html__( 'Auto latest from selected/listened CPT', 'cm-laboratory-hero-widget' ),
		);

		if ( is_multisite() && function_exists( 'get_sites' ) ) {
			$sites = get_sites( array( 'number' => 500 ) );

			foreach ( $sites as $site ) {
				switch_to_blog( (int) $site->blog_id );

				$details   = get_blog_details( $site->blog_id );
				$site_name = $details && ! empty( $details->blogname ) ? $details->blogname : 'Site ' . $site->blog_id;

				$post_types = $this->get_all_known_post_type_slugs();

				foreach ( $post_types as $post_type => $object ) {
					$type_label = isset( $object->labels->singular_name ) ? $object->labels->singular_name : $post_type;

					$posts = get_posts(
						array(
							'post_type'      => $post_type,
							'post_status'    => 'publish',
							'posts_per_page' => 50,
							'orderby'        => 'date',
							'order'          => 'DESC',
						)
					);

					foreach ( $posts as $post ) {
						$key = (int) $site->blog_id . '|' . $post_type . '|' . (int) $post->ID;
						$options[ $key ] = $site_name . ' → ' . $type_label . ' → ' . get_the_title( $post );
					}
				}

				restore_current_blog();
			}
		} else {
			$post_types = $this->get_all_known_post_type_slugs();

			foreach ( $post_types as $post_type => $object ) {
				$type_label = isset( $object->labels->singular_name ) ? $object->labels->singular_name : $post_type;

				$posts = get_posts(
					array(
						'post_type'      => $post_type,
						'post_status'    => 'publish',
						'posts_per_page' => 100,
						'orderby'        => 'date',
						'order'          => 'DESC',
					)
				);

				foreach ( $posts as $post ) {
					$key = 'current|' . $post_type . '|' . (int) $post->ID;
					$options[ $key ] = $type_label . ' → ' . get_the_title( $post );
				}
			}
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'cm_lab_content',
			array(
				'label' => esc_html__( 'Hero Content', 'cm-laboratory-hero-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'background_image',
			array(
				'label'   => esc_html__( 'Background Image', 'cm-laboratory-hero-widget' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'dynamic' => array( 'active' => true ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => esc_html__( 'Title', 'cm-laboratory-hero-widget' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => "Your Orbiting\nLaboratory",
				'placeholder' => esc_html__( 'Add hero title', 'cm-laboratory-hero-widget' ),
				'dynamic'     => array( 'active' => true ),
			)
		);

		$this->add_control(
			'description',
			array(
				'label'       => esc_html__( 'Description', 'cm-laboratory-hero-widget' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => 'Since the first crew’s arrival aboard over twenty years ago, this laboratory has evolved into a state-of-the-art scientific lab.',
				'placeholder' => esc_html__( 'Add description', 'cm-laboratory-hero-widget' ),
				'dynamic'     => array( 'active' => true ),
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'   => esc_html__( 'Button Text', 'cm-laboratory-hero-widget' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'Laboratory Updates',
				'dynamic' => array( 'active' => true ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'       => esc_html__( 'Button Link', 'cm-laboratory-hero-widget' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => 'https://example.com',
				'dynamic'     => array( 'active' => true ),
				'default'     => array(
					'url' => '#',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cm_lab_three_cpt_links',
			array(
				'label' => esc_html__( '3 Separate CPT Bottom Links', 'cm-laboratory-hero-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bottom_link_source',
			array(
				'label'   => esc_html__( 'Bottom Links Source', 'cm-laboratory-hero-widget' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'three_cpt',
				'options' => array(
					'three_cpt' => esc_html__( '3 Separate URL/CPT Listing Links', 'cm-laboratory-hero-widget' ),
					'manual'    => esc_html__( 'Manual Links', 'cm-laboratory-hero-widget' ),
				),
			)
		);

		$this->add_control(
			'three_cpt_notice',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'If a CPT UI or third-party CPT does not show in the dropdown, paste one of its real content URLs in Listing URL Listener. Example: https://connormoizer.com/portfolio/web/nova-login/ — it will infer the site and CPT from the URL path.', 'cm-laboratory-hero-widget' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'condition'       => array(
					'bottom_link_source' => 'three_cpt',
				),
			)
		);

		$cpt_options     = $this->get_cpt_options_for_control();
		$content_options = $this->get_content_options_for_control();

		for ( $i = 1; $i <= 3; $i++ ) {
			$this->add_control(
				"auto_link_{$i}_heading",
				array(
					'label'     => sprintf( esc_html__( 'Auto Link %d', 'cm-laboratory-hero-widget' ), $i ),
					'type'      => \Elementor\Controls_Manager::HEADING,
					'separator' => $i === 1 ? 'none' : 'before',
					'condition' => array(
						'bottom_link_source' => 'three_cpt',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_enabled",
				array(
					'label'        => sprintf( esc_html__( 'Enable Link %d', 'cm-laboratory-hero-widget' ), $i ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Yes', 'cm-laboratory-hero-widget' ),
					'label_off'    => esc_html__( 'No', 'cm-laboratory-hero-widget' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'bottom_link_source' => 'three_cpt',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_listing_url",
				array(
					'label'       => esc_html__( 'Listing URL Listener', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'default'     => '',
					'placeholder' => 'https://connormoizer.com/portfolio/web/nova-login/',
					'description' => esc_html__( 'Paste a real URL from that CPT. The widget uses it to infer the multisite site and CPT listing, then pulls content from there.', 'cm-laboratory-hero-widget' ),
					'label_block' => true,
					'condition'   => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_site_cpt",
				array(
					'label'       => esc_html__( 'Select Site + CPTs', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::SELECT2,
					'default'     => array( array_key_first( $cpt_options ) ),
					'options'     => $cpt_options,
					'multiple'    => true,
					'description' => esc_html__( 'Choose one or more CPTs. The widget compares all selected CPTs and pulls the newest item overall.', 'cm-laboratory-hero-widget' ),
					'label_block' => true,
					'condition'   => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_selected_content",
				array(
					'label'       => esc_html__( 'Select Content', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::SELECT2,
					'default'     => '',
					'options'     => $content_options,
					'description' => esc_html__( 'Choose exact content. Leave as auto latest to pull latest from the selected/listened CPT.', 'cm-laboratory-hero-widget' ),
					'label_block' => true,
					'condition'   => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_slug_override",
				array(
					'label'       => esc_html__( 'CPT Slug Override', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'default'     => '',
					'placeholder' => 'web',
					'description' => esc_html__( 'Only use this if needed. Supports comma-separated CPT slugs like blog,work,reviews,testimonials. You can also use comma-separated slugs like blog,work,reviews,testimonials.', 'cm-laboratory-hero-widget' ),
					'condition'   => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_label",
				array(
					'label'       => esc_html__( 'Small Label', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'default'     => $i === 1 ? 'Portfolio' : ( $i === 2 ? 'Latest Work' : 'Featured' ),
					'placeholder' => 'Latest',
					'condition'   => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_orderby",
				array(
					'label'     => esc_html__( 'Order By', 'cm-laboratory-hero-widget' ),
					'type'      => \Elementor\Controls_Manager::SELECT,
					'default'   => 'date',
					'options'   => array(
						'date'       => esc_html__( 'Latest Published', 'cm-laboratory-hero-widget' ),
						'title'      => esc_html__( 'Title', 'cm-laboratory-hero-widget' ),
						'menu_order' => esc_html__( 'Menu Order', 'cm-laboratory-hero-widget' ),
					),
					'condition' => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_order",
				array(
					'label'     => esc_html__( 'Order', 'cm-laboratory-hero-widget' ),
					'type'      => \Elementor\Controls_Manager::SELECT,
					'default'   => 'DESC',
					'options'   => array(
						'DESC' => 'DESC',
						'ASC'  => 'ASC',
					),
					'condition' => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);

			$this->add_control(
				"auto_link_{$i}_offset",
				array(
					'label'       => esc_html__( 'Skip Posts', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'default'     => 0,
					'min'         => 0,
					'max'         => 50,
					'description' => esc_html__( 'Use 0 for latest, 1 for second latest, 2 for third latest.', 'cm-laboratory-hero-widget' ),
					'condition'   => array(
						'bottom_link_source' => 'three_cpt',
						"auto_link_{$i}_enabled" => 'yes',
					),
				)
			);
		}

		$this->end_controls_section();

		$this->start_controls_section(
			'cm_lab_links',
			array(
				'label' => esc_html__( 'Manual Bottom Links', 'cm-laboratory-hero-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => array(
					'bottom_link_source' => 'manual',
				),
			)
		);

		for ( $i = 1; $i <= 3; $i++ ) {
			$defaults = array(
				1 => array( 'label' => 'Current Mission', 'text' => 'Expedition 74' ),
				2 => array( 'label' => 'Benefits To You', 'text' => 'Laboratory Science' ),
				3 => array( 'label' => 'Real-Time Tracking', 'text' => 'Track the Mission' ),
			);

			$this->add_control(
				"link_{$i}_heading",
				array(
					'label'     => sprintf( esc_html__( 'Link %d', 'cm-laboratory-hero-widget' ), $i ),
					'type'      => \Elementor\Controls_Manager::HEADING,
					'separator' => $i === 1 ? 'none' : 'before',
				)
			);

			$this->add_control(
				"link_{$i}_label",
				array(
					'label'   => esc_html__( 'Small Label', 'cm-laboratory-hero-widget' ),
					'type'    => \Elementor\Controls_Manager::TEXT,
					'default' => $defaults[ $i ]['label'],
					'dynamic' => array( 'active' => true ),
				)
			);

			$this->add_control(
				"link_{$i}_text",
				array(
					'label'   => esc_html__( 'Main Text', 'cm-laboratory-hero-widget' ),
					'type'    => \Elementor\Controls_Manager::TEXT,
					'default' => $defaults[ $i ]['text'],
					'dynamic' => array( 'active' => true ),
				)
			);

			$this->add_control(
				"link_{$i}_url",
				array(
					'label'       => esc_html__( 'URL', 'cm-laboratory-hero-widget' ),
					'type'        => \Elementor\Controls_Manager::URL,
					'placeholder' => 'https://example.com',
					'dynamic'     => array( 'active' => true ),
					'default'     => array(
						'url' => '#',
					),
				)
			);
		}

		$this->end_controls_section();

		$this->start_controls_section(
			'cm_lab_options',
			array(
				'label' => esc_html__( 'Layout Options', 'cm-laboratory-hero-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'overlay_strength',
			array(
				'label'   => esc_html__( 'Overlay Strength', 'cm-laboratory-hero-widget' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'strong',
				'options' => array(
					'light'  => esc_html__( 'Light', 'cm-laboratory-hero-widget' ),
					'medium' => esc_html__( 'Medium', 'cm-laboratory-hero-widget' ),
					'strong' => esc_html__( 'Strong', 'cm-laboratory-hero-widget' ),
				),
			)
		);

		$this->add_control(
			'text_position',
			array(
				'label'   => esc_html__( 'Text Position', 'cm-laboratory-hero-widget' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'bottom_left',
				'options' => array(
					'bottom_left' => esc_html__( 'Bottom Left', 'cm-laboratory-hero-widget' ),
					'middle_left' => esc_html__( 'Middle Left', 'cm-laboratory-hero-widget' ),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cm_lab_style',
			array(
				'label' => esc_html__( 'Style', 'cm-laboratory-hero-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'hero_height',
			array(
				'label'      => esc_html__( 'Hero Height', 'cm-laboratory-hero-widget' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'vh' ),
				'range'      => array(
					'px' => array( 'min' => 420, 'max' => 1000 ),
					'vh' => array( 'min' => 50, 'max' => 100 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 680,
				),
				'selectors'  => array(
					'{{WRAPPER}} .cm-lab-hero' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'button_colour',
			array(
				'label'     => esc_html__( 'Button Colour', 'cm-laboratory-hero-widget' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#d83933',
				'selectors' => array(
					'{{WRAPPER}} .cm-lab-hero__button' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'text_colour',
			array(
				'label'     => esc_html__( 'Text Colour', 'cm-laboratory-hero-widget' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .cm-lab-hero, {{WRAPPER}} .cm-lab-hero h1, {{WRAPPER}} .cm-lab-hero p, {{WRAPPER}} .cm-lab-hero a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function build_url_attrs( $settings, $key ) {
		$link = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
		$url  = ! empty( $link['url'] ) ? $link['url'] : '#';

		$attrs = array(
			'href' => esc_url( $url ),
		);

		if ( ! empty( $link['is_external'] ) ) {
			$attrs['target'] = '_blank';
		}

		if ( ! empty( $link['nofollow'] ) ) {
			$attrs['rel'] = 'nofollow';
		}

		$out = '';

		foreach ( $attrs as $attr => $value ) {
			$out .= sprintf( ' %s="%s"', esc_attr( $attr ), esc_attr( $value ) );
		}

		return $out;
	}

	private function split_selector_value( $value ) {
		$parts = explode( '|', (string) $value );

		return array(
			'site'      => isset( $parts[0] ) ? $parts[0] : 'current',
			'post_type' => isset( $parts[1] ) ? sanitize_key( $parts[1] ) : 'post',
			'post_id'   => isset( $parts[2] ) ? absint( $parts[2] ) : 0,
		);
	}

	private function infer_site_and_cpt_from_listing_url( $url ) {
		$url = trim( (string) $url );

		if ( empty( $url ) ) {
			return null;
		}

		$url = esc_url_raw( $url );

		if ( empty( $url ) ) {
			return null;
		}

		$result = array(
			'site'      => 'current',
			'post_type' => '',
			'post_id'   => 0,
			'url'       => $url,
		);

		$path = trim( wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$parts = $path ? explode( '/', $path ) : array();

		if ( is_multisite() && function_exists( 'get_sites' ) ) {
			$sites = get_sites( array( 'number' => 500 ) );

			foreach ( $sites as $site ) {
				switch_to_blog( (int) $site->blog_id );

				$home = trailingslashit( home_url() );

				if ( 0 === strpos( trailingslashit( $url ), $home ) ) {
					$result['site'] = (string) (int) $site->blog_id;

					$home_path = trim( wp_parse_url( $home, PHP_URL_PATH ), '/' );

					if ( $home_path && 0 === strpos( $path, $home_path ) ) {
						$path = trim( substr( $path, strlen( $home_path ) ), '/' );
						$parts = $path ? explode( '/', $path ) : array();
					}

					restore_current_blog();
					break;
				}

				restore_current_blog();
			}
		}

		$site_id = $result['site'];
		$switched = false;

		if ( is_multisite() && 'current' !== $site_id ) {
			$site_id = absint( $site_id );

			if ( $site_id && get_current_blog_id() !== $site_id ) {
				switch_to_blog( $site_id );
				$switched = true;
			}
		}

		$post_id = url_to_postid( $url );

		if ( $post_id ) {
			$post = get_post( $post_id );

			if ( $post ) {
				$result['post_id']   = (int) $post_id;
				$result['post_type'] = $post->post_type;
			}
		}

		if ( empty( $result['post_type'] ) && ! empty( $parts ) ) {
			$known_types = $this->get_all_known_post_type_slugs();
			$known_slugs = array_keys( $known_types );

			foreach ( $parts as $part ) {
				$possible = sanitize_key( $part );

				if ( in_array( $possible, $known_slugs, true ) ) {
					$result['post_type'] = $possible;
					break;
				}
			}
		}

		if ( empty( $result['post_type'] ) && count( $parts ) >= 2 ) {
			$maybe_cpt = sanitize_key( $parts[ count( $parts ) - 2 ] );

			if ( $maybe_cpt ) {
				$result['post_type'] = $maybe_cpt;
			}
		}

		if ( $switched ) {
			restore_current_blog();
		}

		return ! empty( $result['post_type'] ) ? $result : null;
	}

	private function normalise_selected_cpts( $value ) {
		if ( empty( $value ) ) {
			return array();
		}

		if ( is_string( $value ) ) {
			return array( $this->split_selector_value( $value ) );
		}

		if ( is_array( $value ) ) {
			$out = array();

			foreach ( $value as $item ) {
				if ( is_string( $item ) && '' !== $item ) {
					$out[] = $this->split_selector_value( $item );
				}
			}

			return $out;
		}

		return array();
	}

	private function get_latest_from_site_cpt_group( $site_id, $post_types, $orderby, $order, $offset ) {
		$post_types = array_filter( array_unique( array_map( 'sanitize_key', (array) $post_types ) ) );

		if ( empty( $post_types ) ) {
			return null;
		}

		$switched = false;

		if ( is_multisite() && 'current' !== $site_id ) {
			$site_id = absint( $site_id );

			if ( $site_id && get_current_blog_id() !== $site_id ) {
				switch_to_blog( $site_id );
				$switched = true;
			}
		}

		$query = new \WP_Query(
			array(
				'post_type'           => $post_types,
				'post_status'         => 'publish',
				'posts_per_page'      => 1,
				'offset'              => absint( $offset ),
				'orderby'             => $orderby,
				'order'               => $order,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		$link = null;

		if ( $query->have_posts() ) {
			$post = $query->posts[0];

			$link = array(
				'title'     => get_the_title( $post ),
				'url'       => get_permalink( $post ),
				'date'      => (int) get_post_time( 'U', true, $post ),
				'post_type' => get_post_type( $post ),
				'blog_id'   => get_current_blog_id(),
			);
		}

		wp_reset_postdata();

		if ( $switched ) {
			restore_current_blog();
		}

		return $link;
	}

	private function compare_latest_links( $current_best, $candidate, $orderby, $order ) {
		if ( ! $candidate ) {
			return $current_best;
		}

		if ( ! $current_best ) {
			return $candidate;
		}

		if ( 'date' === $orderby ) {
			if ( 'ASC' === $order ) {
				return ( $candidate['date'] < $current_best['date'] ) ? $candidate : $current_best;
			}

			return ( $candidate['date'] > $current_best['date'] ) ? $candidate : $current_best;
		}

		return $current_best;
	}


	private function get_one_cpt_link( $settings, $index ) {
		if ( empty( $settings[ "auto_link_{$index}_enabled" ] ) || 'yes' !== $settings[ "auto_link_{$index}_enabled" ] ) {
			return null;
		}

		$listing = null;

		if ( ! empty( $settings[ "auto_link_{$index}_listing_url" ] ) ) {
			$listing = $this->infer_site_and_cpt_from_listing_url( $settings[ "auto_link_{$index}_listing_url" ] );
		}

		$selected_content = ! empty( $settings[ "auto_link_{$index}_selected_content" ] ) ? $this->split_selector_value( $settings[ "auto_link_{$index}_selected_content" ] ) : null;
		$selected_cpts    = ! empty( $settings[ "auto_link_{$index}_site_cpt" ] ) ? $this->normalise_selected_cpts( $settings[ "auto_link_{$index}_site_cpt" ] ) : array();

		if ( empty( $selected_cpts ) ) {
			$selected_cpts = array( $this->split_selector_value( 'current|post' ) );
		}

		$label   = ! empty( $settings[ "auto_link_{$index}_label" ] ) ? $settings[ "auto_link_{$index}_label" ] : 'Latest';
		$order   = ! empty( $settings[ "auto_link_{$index}_order" ] ) && 'ASC' === strtoupper( $settings[ "auto_link_{$index}_order" ] ) ? 'ASC' : 'DESC';
		$orderby = ! empty( $settings[ "auto_link_{$index}_orderby" ] ) ? sanitize_key( $settings[ "auto_link_{$index}_orderby" ] ) : 'date';
		$offset  = isset( $settings[ "auto_link_{$index}_offset" ] ) ? absint( $settings[ "auto_link_{$index}_offset" ] ) : 0;

		if ( ! in_array( $orderby, array( 'date', 'title', 'menu_order' ), true ) ) {
			$orderby = 'date';
		}

		if ( $listing ) {
			$site_id    = $listing['site'];
			$post_types = array( $listing['post_type'] );
			$post_id    = ! empty( $listing['post_id'] ) ? absint( $listing['post_id'] ) : 0;
		} elseif ( $selected_content && ! empty( $selected_content['post_id'] ) ) {
			$site_id    = $selected_content['site'];
			$post_types = array( $selected_content['post_type'] );
			$post_id    = $selected_content['post_id'];
		} else {
			$post_id = 0;

			$groups = array();

			foreach ( $selected_cpts as $selected ) {
				$site = ! empty( $selected['site'] ) ? $selected['site'] : 'current';
				$type = ! empty( $selected['post_type'] ) ? sanitize_key( $selected['post_type'] ) : 'post';

				if ( ! isset( $groups[ $site ] ) ) {
					$groups[ $site ] = array();
				}

				$groups[ $site ][] = $type;
			}

			if ( ! empty( $settings[ "auto_link_{$index}_slug_override" ] ) ) {
				$first = reset( $selected_cpts );
				$site_id = ! empty( $first['site'] ) ? $first['site'] : 'current';
				$groups = array(
					$site_id => array_map( 'sanitize_key', array_map( 'trim', explode( ',', $settings[ "auto_link_{$index}_slug_override" ] ) ) ),
				);
			}

			$best = null;

			foreach ( $groups as $site_id_for_group => $types_for_group ) {
				$link_from_group = $this->get_latest_from_site_cpt_group( $site_id_for_group, $types_for_group, $orderby, $order, $offset );
				$best = $this->compare_latest_links( $best, $link_from_group, $orderby, $order );
			}

			if ( $best ) {
				return array(
					'label' => $label,
					'text'  => $best['title'],
					'url'   => $best['url'],
				);
			}

			$site_id    = 'current';
			$post_types = array( 'post' );
		}

		if ( ! empty( $settings[ "auto_link_{$index}_slug_override" ] ) ) {
			$post_types = array_map( 'sanitize_key', array_map( 'trim', explode( ',', $settings[ "auto_link_{$index}_slug_override" ] ) ) );
		}

		$switched = false;

		if ( is_multisite() && 'current' !== $site_id ) {
			$site_id = absint( $site_id );

			if ( $site_id && get_current_blog_id() !== $site_id ) {
				switch_to_blog( $site_id );
				$switched = true;
			}
		}

		$link = null;

		if ( ! empty( $post_id ) ) {
			$post = get_post( $post_id );

			if ( $post && 'publish' === $post->post_status ) {
				$link = array(
					'label' => $label,
					'text'  => get_the_title( $post ),
					'url'   => get_permalink( $post ),
				);
			}
		}

		if ( ! $link ) {
			$query = new \WP_Query(
				array(
					'post_type'           => $post_types,
					'post_status'         => 'publish',
					'posts_per_page'      => 1,
					'offset'              => $offset,
					'orderby'             => $orderby,
					'order'               => $order,
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
				)
			);

			if ( $query->have_posts() ) {
				$post = $query->posts[0];

				$link = array(
					'label' => $label,
					'text'  => get_the_title( $post ),
					'url'   => get_permalink( $post ),
				);
			}

			wp_reset_postdata();
		}

		if ( $switched ) {
			restore_current_blog();
		}

		if ( ! $link && ! empty( $settings[ "auto_link_{$index}_listing_url" ] ) ) {
			$link = array(
				'label' => $label,
				'text'  => esc_html__( 'Linked Content', 'cm-laboratory-hero-widget' ),
				'url'   => esc_url_raw( $settings[ "auto_link_{$index}_listing_url" ] ),
			);
		}

		return $link;
	}

	private function get_three_cpt_links( $settings ) {
		$links = array();

		for ( $i = 1; $i <= 3; $i++ ) {
			$link = $this->get_one_cpt_link( $settings, $i );

			if ( $link ) {
				$links[] = $link;
			}
		}

		return $links;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$bg_url = '';
		if ( ! empty( $settings['background_image']['url'] ) ) {
			$bg_url = $settings['background_image']['url'];
		}

		$overlay = ! empty( $settings['overlay_strength'] ) ? $settings['overlay_strength'] : 'strong';
		$position = ! empty( $settings['text_position'] ) ? $settings['text_position'] : 'bottom_left';

		$classes = array(
			'cm-lab-hero',
			'cm-lab-hero--overlay-' . sanitize_html_class( $overlay ),
			'cm-lab-hero--position-' . sanitize_html_class( $position ),
		);

		$style = '';
		if ( $bg_url ) {
			$style = sprintf( ' style="background-image:url(%s);"', esc_url( $bg_url ) );
		}

		$auto_links = array();
		if ( ! empty( $settings['bottom_link_source'] ) && 'three_cpt' === $settings['bottom_link_source'] ) {
			$auto_links = $this->get_three_cpt_links( $settings );
		}
		?>
		<section class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"<?php echo $style; ?>>
			<div class="cm-lab-hero__shade" aria-hidden="true"></div>

			<div class="cm-lab-hero__content">
				<?php if ( ! empty( $settings['title'] ) ) : ?>
					<h1><?php echo nl2br( esc_html( $settings['title'] ) ); ?></h1>
				<?php endif; ?>

				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<p><?php echo esc_html( $settings['description'] ); ?></p>
				<?php endif; ?>

				<?php if ( ! empty( $settings['button_text'] ) ) : ?>
					<a class="cm-lab-hero__button"<?php echo $this->build_url_attrs( $settings, 'button_link' ); ?>>
						<span><?php echo esc_html( $settings['button_text'] ); ?></span>
						<span class="cm-lab-hero__button-icon" aria-hidden="true">›</span>
					</a>
				<?php endif; ?>
			</div>

			<div class="cm-lab-hero__links">
				<?php if ( ! empty( $auto_links ) ) : ?>
					<?php foreach ( $auto_links as $link ) : ?>
						<a class="cm-lab-hero__link" href="<?php echo esc_url( $link['url'] ); ?>">
							<span class="cm-lab-hero__link-label"><?php echo esc_html( $link['label'] ); ?></span>
							<span class="cm-lab-hero__link-text">
								<?php echo esc_html( $link['text'] ); ?>
								<span aria-hidden="true">›</span>
							</span>
						</a>
					<?php endforeach; ?>
				<?php else : ?>
					<?php for ( $i = 1; $i <= 3; $i++ ) : ?>
						<?php
						$label = ! empty( $settings[ "link_{$i}_label" ] ) ? $settings[ "link_{$i}_label" ] : '';
						$text  = ! empty( $settings[ "link_{$i}_text" ] ) ? $settings[ "link_{$i}_text" ] : '';

						if ( ! $label && ! $text ) {
							continue;
						}
						?>
						<a class="cm-lab-hero__link"<?php echo $this->build_url_attrs( $settings, "link_{$i}_url" ); ?>>
							<?php if ( $label ) : ?>
								<span class="cm-lab-hero__link-label"><?php echo esc_html( $label ); ?></span>
							<?php endif; ?>

							<?php if ( $text ) : ?>
								<span class="cm-lab-hero__link-text">
									<?php echo esc_html( $text ); ?>
									<span aria-hidden="true">›</span>
								</span>
							<?php endif; ?>
						</a>
					<?php endfor; ?>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}
