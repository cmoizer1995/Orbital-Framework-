<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CM_Link_Bio_Widget' ) ) :

class CM_Link_Bio_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'cm_link_bio'; }
	public function get_title() { return esc_html__( 'CM Link Bio', 'cm-editorial-widgets' ); }
	public function get_icon() { return 'eicon-link'; }
	public function get_categories() { return array( 'cm-editorial-widgets' ); }
	public function get_keywords() { return array( 'link bio', 'links', 'profile', 'social', 'buttons' ); }
	public function get_style_depends() { return array( 'cm-link-bio-widget' ); }

	protected function register_controls() {
		$this->start_controls_section( 'display_section', array(
			'label' => esc_html__( 'Display', 'cm-editorial-widgets' ),
			'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		) );

		$this->add_control( 'show_profile', array(
			'label'        => esc_html__( 'Show Profile/Bio', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => 'yes',
		) );

		$this->add_control( 'show_avatar', array(
			'label'        => esc_html__( 'Show Profile Image', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => array( 'show_profile' => 'yes' ),
		) );

		$this->add_control( 'show_name', array(
			'label'        => esc_html__( 'Show Name', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => array( 'show_profile' => 'yes' ),
		) );

		$this->add_control( 'show_username', array(
			'label'        => esc_html__( 'Show Username/Handle', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => array( 'show_profile' => 'yes' ),
		) );

		$this->add_control( 'show_bio', array(
			'label'        => esc_html__( 'Show Bio Text', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => array( 'show_profile' => 'yes' ),
		) );

		$this->add_control( 'show_links', array(
			'label'        => esc_html__( 'Show Links', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => 'yes',
		) );

		$this->add_control( 'force_reference_colours', array(
			'label'        => esc_html__( 'Use Reference Link Colours', 'cm-editorial-widgets' ),
			'description'  => esc_html__( 'Keeps the default colours like the reference screenshot. Turn off to use each link colour picker.', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Yes', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'No', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => 'yes',
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'profile_section', array(
			'label' => esc_html__( 'Profile/Bio Content', 'cm-editorial-widgets' ),
			'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			'condition' => array( 'show_profile' => 'yes' ),
		) );

		$this->add_control( 'avatar', array(
			'label'     => esc_html__( 'Profile Image', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::MEDIA,
			'condition' => array( 'show_avatar' => 'yes' ),
		) );

		$this->add_control( 'profile_name', array(
			'label'       => esc_html__( 'Profile Name', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => 'Connor Moizer',
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
			'condition'   => array( 'show_name' => 'yes' ),
		) );

		$this->add_control( 'username', array(
			'label'       => esc_html__( 'Username / Handle', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => '@cmoizer1995',
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
			'condition'   => array( 'show_username' => 'yes' ),
		) );

		$this->add_control( 'bio', array(
			'label'       => esc_html__( 'Bio Lines', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXTAREA,
			'default'     => "Portfolio • Blogs • Projects\nWordPress • Elementor",
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
			'condition'   => array( 'show_bio' => 'yes' ),
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'links_section', array(
			'label' => esc_html__( 'Links', 'cm-editorial-widgets' ),
			'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			'condition' => array( 'show_links' => 'yes' ),
		) );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control( 'show_item', array(
			'label'        => esc_html__( 'Show Link', 'cm-editorial-widgets' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Show', 'cm-editorial-widgets' ),
			'label_off'    => esc_html__( 'Hide', 'cm-editorial-widgets' ),
			'return_value' => 'yes',
			'default'      => 'yes',
		) );

		$repeater->add_control( 'icon', array(
			'label'   => esc_html__( 'Icon', 'cm-editorial-widgets' ),
			'type'    => \Elementor\Controls_Manager::ICONS,
			'default' => array( 'value' => 'fas fa-link', 'library' => 'fa-solid' ),
		) );

		$repeater->add_control( 'logo_image', array(
			'label'       => esc_html__( 'Logo / Image Auto Colour', 'cm-editorial-widgets' ),
			'description' => esc_html__( 'Upload a logo and the button colour will automatically use the main colour from that logo.', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::MEDIA,
		) );

		$repeater->add_control( 'title', array(
			'label'       => esc_html__( 'Title', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => 'YouTube',
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'subtitle', array(
			'label'       => esc_html__( 'Subtitle', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => 'Subscribe for videos',
			'label_block' => true,
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'url', array(
			'label'       => esc_html__( 'URL', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::URL,
			'default'     => array( 'url' => '#', 'is_external' => true ),
			'placeholder' => 'https://example.com',
			'dynamic'     => array( 'active' => true ),
		) );

		$repeater->add_control( 'accent_colour', array(
			'label'   => esc_html__( 'Button Colour', 'cm-editorial-widgets' ),
			'type'    => \Elementor\Controls_Manager::COLOR,
			'default' => '#ff2d55',
		) );

		$repeater->add_control( 'icon_colour', array(
			'label'   => esc_html__( 'Icon Colour', 'cm-editorial-widgets' ),
			'type'    => \Elementor\Controls_Manager::COLOR,
			'default' => '#ffffff',
		) );

		$this->add_control( 'items', array(
			'label'       => esc_html__( 'Link Buttons', 'cm-editorial-widgets' ),
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'title_field' => '{{{ title }}}',
			'default'     => array(
				array( 'title' => 'Donate', 'subtitle' => 'Donate via PayPal or a card!', 'accent_colour' => '#0070ba', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-paypal', 'library' => 'fa-brands' ) ),
				array( 'title' => 'Twitch', 'subtitle' => 'Join my livestreams!', 'accent_colour' => '#9146ff', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-twitch', 'library' => 'fa-brands' ) ),
				array( 'title' => 'Discord', 'subtitle' => 'Join my Discord!', 'accent_colour' => '#5865f2', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-discord', 'library' => 'fa-brands' ) ),
				array( 'title' => 'Amazon Finds', 'subtitle' => 'Browse favourite items & gear!', 'accent_colour' => '#ff9900', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-amazon', 'library' => 'fa-brands' ) ),
				array( 'title' => 'Merch', 'subtitle' => 'Get the latest merch!', 'accent_colour' => '#ff2d55', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fas fa-tshirt', 'library' => 'fa-solid' ) ),
				array( 'title' => 'My Gear', 'subtitle' => 'My camera and streaming gear!', 'accent_colour' => '#39c5d8', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fas fa-gamepad', 'library' => 'fa-solid' ) ),
				array( 'title' => 'YouTube', 'subtitle' => 'Subscribe for clips, videos & streams!', 'accent_colour' => '#ff0000', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-youtube', 'library' => 'fa-brands' ) ),
				array( 'title' => 'Twitter', 'subtitle' => 'Follow my latest updates!', 'accent_colour' => '#1da1f2', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-twitter', 'library' => 'fa-brands' ) ),
				array( 'title' => 'Instagram', 'subtitle' => 'Follow my latest posts!', 'accent_colour' => '#e1306c', 'icon_colour' => '#ffffff', 'icon' => array( 'value' => 'fab fa-instagram', 'library' => 'fa-brands' ) ),
			),
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'style_section', array(
			'label' => esc_html__( 'Style', 'cm-editorial-widgets' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'widget_background', array(
			'label'     => esc_html__( 'Widget Background', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'default'   => '#ffffff',
			'selectors' => array( '{{WRAPPER}} .cm-link-bio' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_control( 'text_colour', array(
			'label'     => esc_html__( 'Text Colour', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'default'   => '#000000',
			'selectors' => array( '{{WRAPPER}} .cm-link-bio, {{WRAPPER}} .cm-link-bio a, {{WRAPPER}} .cm-link-bio__text strong, {{WRAPPER}} .cm-link-bio__text small' => 'color: {{VALUE}};' ),
		) );

		$this->add_responsive_control( 'widget_padding', array(
			'label'      => esc_html__( 'Widget Padding', 'cm-editorial-widgets' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px' ),
			'default'    => array( 'top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0, 'unit' => 'px', 'isLinked' => true ),
			'selectors'  => array( '{{WRAPPER}} .cm-link-bio' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_control( 'title_size', array(
			'label'     => esc_html__( 'Link Title Size', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 12, 'max' => 36 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 20 ),
			'selectors' => array( '{{WRAPPER}} .cm-link-bio__text strong' => 'font-size: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'subtitle_size', array(
			'label'     => esc_html__( 'Subtitle Size', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 10, 'max' => 24 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 12 ),
			'selectors' => array( '{{WRAPPER}} .cm-link-bio__text small' => 'font-size: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'icon_size', array(
			'label'     => esc_html__( 'Icon Size', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 14, 'max' => 50 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 30 ),
			'selectors' => array(
				'{{WRAPPER}} .cm-link-bio__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .cm-link-bio__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_control( 'border_width', array(
			'label'     => esc_html__( 'Border Width', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 1, 'max' => 8 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 3 ),
			'selectors' => array( '{{WRAPPER}} .cm-link-bio__item' => 'border-width: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'border_radius', array(
			'label'     => esc_html__( 'Border Radius', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 10 ),
			'selectors' => array( '{{WRAPPER}} .cm-link-bio__item, {{WRAPPER}} .cm-link-bio__icon-box' => 'border-radius: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'link_gap', array(
			'label'     => esc_html__( 'Link Spacing', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 4, 'max' => 40 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 12 ),
			'selectors' => array( '{{WRAPPER}} .cm-link-bio__items' => 'gap: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'link_height', array(
			'label'     => esc_html__( 'Link Height', 'cm-editorial-widgets' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 44, 'max' => 140 ) ),
			'default'   => array( 'unit' => 'px', 'size' => 66 ),
			'selectors' => array( '{{WRAPPER}} .cm-link-bio__item' => 'min-height: {{SIZE}}{{UNIT}};' ),
		) );

		$this->end_controls_section();
	}




	private function cm_normalise_hex_colour( $colour ) {
		$colour = trim( (string) $colour );

		if ( '' === $colour ) {
			return '';
		}

		// Elementor can pass a raw typed hex, with or without #.
		if ( preg_match( '/^#?([0-9a-fA-F]{3})$/', $colour, $m ) ) {
			$hex = strtolower( $m[1] );
			return '#' . $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}

		if ( preg_match( '/^#?([0-9a-fA-F]{6})$/', $colour, $m ) ) {
			return '#' . strtolower( $m[1] );
		}

		return '';
	}

	private function cm_get_brand_colour_from_item( $item ) {
		$text = '';

		if ( ! empty( $item['title'] ) ) {
			$text .= ' ' . strtolower( (string) $item['title'] );
		}

		if ( ! empty( $item['subtitle'] ) ) {
			$text .= ' ' . strtolower( (string) $item['subtitle'] );
		}

		if ( ! empty( $item['url']['url'] ) ) {
			$text .= ' ' . strtolower( (string) $item['url']['url'] );
		}

		if ( ! empty( $item['icon']['value'] ) ) {
			$text .= ' ' . strtolower( (string) $item['icon']['value'] );
		}

		$map = array(
			'#ff0000' => array( 'youtube', 'fa-youtube', 'youtu.be' ),
			'#25f4ee' => array( 'tiktok', 'fa-tiktok', 'vm.tiktok', 'vt.tiktok' ),
			'#9146ff' => array( 'twitch', 'fa-twitch' ),
			'#5865f2' => array( 'discord', 'fa-discord', 'discord.gg' ),
			'#ff9900' => array( 'amazon', 'amazon finds', 'fa-amazon', 'amzn.to', 'a.co' ),
			'#0070ba' => array( 'paypal', 'donate', 'fa-paypal' ),
			'#e1306c' => array( 'instagram', 'fa-instagram' ),
			'#1da1f2' => array( 'twitter', 'x.com', 'fa-twitter', 'fa-x-twitter' ),
			'#ff2d55' => array( 'merch', 'shop', 'shirt', 'tshirt', 't-shirt', 'fa-shirt', 'fa-tshirt' ),
			'#39c5d8' => array( 'my gear', 'gear', 'kit', 'camera', 'streaming', 'fa-gamepad' ),
			'#1877f2' => array( 'facebook', 'fa-facebook' ),
			'#1ab7ea' => array( 'vimeo', 'fa-vimeo' ),
		);

		foreach ( $map as $colour => $needles ) {
			foreach ( $needles as $needle ) {
				if ( false !== strpos( $text, $needle ) ) {
					return $colour;
				}
			}
		}

		return '';
	}

	private function cm_get_dominant_logo_colour( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id ) {
			return '';
		}

		$cache_key = 'cm_link_bio_logo_colour_' . $attachment_id;
		$cached    = get_transient( $cache_key );

		if ( is_string( $cached ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $cached ) ) {
			return $cached;
		}

		$file = get_attached_file( $attachment_id );

		if ( ! $file || ! file_exists( $file ) ) {
			return '';
		}

		$colour = $this->cm_extract_dominant_colour_from_file( $file );

		if ( $colour ) {
			set_transient( $cache_key, $colour, MONTH_IN_SECONDS );
		}

		return $colour;
	}

	private function cm_extract_dominant_colour_from_file( $file ) {
		if ( ! function_exists( 'imagecreatetruecolor' ) ) {
			return '';
		}

		$info = @getimagesize( $file );

		if ( empty( $info['mime'] ) ) {
			return '';
		}

		switch ( $info['mime'] ) {
			case 'image/jpeg':
				if ( ! function_exists( 'imagecreatefromjpeg' ) ) {
					return '';
				}
				$image = @imagecreatefromjpeg( $file );
				break;

			case 'image/png':
				if ( ! function_exists( 'imagecreatefrompng' ) ) {
					return '';
				}
				$image = @imagecreatefrompng( $file );
				break;

			case 'image/gif':
				if ( ! function_exists( 'imagecreatefromgif' ) ) {
					return '';
				}
				$image = @imagecreatefromgif( $file );
				break;

			case 'image/webp':
				if ( ! function_exists( 'imagecreatefromwebp' ) ) {
					return '';
				}
				$image = @imagecreatefromwebp( $file );
				break;

			default:
				return '';
		}

		if ( ! $image ) {
			return '';
		}

		$width  = imagesx( $image );
		$height = imagesy( $image );

		if ( ! $width || ! $height ) {
			imagedestroy( $image );
			return '';
		}

		$buckets = array();
		$sample  = 8;

		for ( $x = 0; $x < $width; $x += $sample ) {
			for ( $y = 0; $y < $height; $y += $sample ) {
				$rgba = imagecolorat( $image, $x, $y );

				$r = ( $rgba >> 16 ) & 0xFF;
				$g = ( $rgba >> 8 ) & 0xFF;
				$b = $rgba & 0xFF;

				// Skip near-white, near-black and grey pixels so logos pick the actual brand colour.
				$max = max( $r, $g, $b );
				$min = min( $r, $g, $b );

				if ( $max > 238 || $max < 35 || ( $max - $min ) < 28 ) {
					continue;
				}

				$qr  = (int) round( $r / 32 ) * 32;
				$qg  = (int) round( $g / 32 ) * 32;
				$qb  = (int) round( $b / 32 ) * 32;
				$key = $qr . ',' . $qg . ',' . $qb;

				if ( ! isset( $buckets[ $key ] ) ) {
					$buckets[ $key ] = array(
						'count' => 0,
						'r'     => 0,
						'g'     => 0,
						'b'     => 0,
					);
				}

				$buckets[ $key ]['count']++;
				$buckets[ $key ]['r'] += $r;
				$buckets[ $key ]['g'] += $g;
				$buckets[ $key ]['b'] += $b;
			}
		}

		imagedestroy( $image );

		if ( empty( $buckets ) ) {
			return '';
		}

		usort(
			$buckets,
			function( $a, $b ) {
				return $b['count'] <=> $a['count'];
			}
		);

		$best = $buckets[0];

		$r = (int) round( $best['r'] / max( 1, $best['count'] ) );
		$g = (int) round( $best['g'] / max( 1, $best['count'] ) );
		$b = (int) round( $best['b'] / max( 1, $best['count'] ) );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	private function attrs( $item ) {
		$url = ! empty( $item['url']['url'] ) ? $item['url']['url'] : '#';
		$attrs = 'href="' . esc_url( $url ) . '"';

		if ( ! empty( $item['url']['is_external'] ) ) {
			$attrs .= ' target="_blank" rel="noopener noreferrer"';
		}

		return $attrs;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="cm-link-bio <?php echo ( ! empty( $settings['force_reference_colours'] ) && 'yes' === $settings['force_reference_colours'] ) ? 'cm-link-bio--reference-colours' : ''; ?>">
			<?php if ( ! empty( $settings['show_profile'] ) && 'yes' === $settings['show_profile'] ) : ?>
				<div class="cm-link-bio__profile">
					<?php if ( ! empty( $settings['show_avatar'] ) && 'yes' === $settings['show_avatar'] && ! empty( $settings['avatar']['url'] ) ) : ?>
						<img src="<?php echo esc_url( $settings['avatar']['url'] ); ?>" alt="">
					<?php endif; ?>
					<?php if ( ! empty( $settings['show_name'] ) && 'yes' === $settings['show_name'] && ! empty( $settings['profile_name'] ) ) : ?>
						<h2><?php echo esc_html( $settings['profile_name'] ); ?></h2>
					<?php endif; ?>
					<?php if ( ! empty( $settings['show_username'] ) && 'yes' === $settings['show_username'] && ! empty( $settings['username'] ) ) : ?>
						<div class="cm-link-bio__user"><?php echo esc_html( $settings['username'] ); ?></div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['show_bio'] ) && 'yes' === $settings['show_bio'] && ! empty( $settings['bio'] ) ) : ?>
						<div class="cm-link-bio__bio"><?php echo nl2br( esc_html( $settings['bio'] ) ); ?></div>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['show_links'] ) && 'yes' === $settings['show_links'] ) : ?>
				<div class="cm-link-bio__items">
					<?php foreach ( (array) $settings['items'] as $item ) : ?>
						<?php
						if ( isset( $item['show_item'] ) && 'yes' !== $item['show_item'] ) {
							continue;
						}
						$manual_accent = ! empty( $item['accent_colour'] ) ? $this->cm_normalise_hex_colour( $item['accent_colour'] ) : '';

						/*
						 * Button Colour must win.
						 * If a hex is typed into the Button Colour field, it is forced onto the front-end.
						 * Auto brand/logo colour only runs when Button Colour is empty or not a valid hex.
						 */
						if ( $manual_accent ) {
							$accent = $manual_accent;
						} else {
							$accent = $this->cm_get_brand_colour_from_item( $item );

							if ( ! $accent && ! empty( $item['logo_image']['id'] ) ) {
								$accent = $this->cm_get_dominant_logo_colour( $item['logo_image']['id'] );
							}

							if ( ! $accent ) {
								$accent = '#ff2d55';
							}
						}

						$icon = ! empty( $item['icon_colour'] ) ? $item['icon_colour'] : '#ffffff';
						?>
						<a class="cm-link-bio__item" <?php echo $this->attrs( $item ); ?> style="--cm-link-bio-accent: <?php echo esc_attr( $accent ); ?>; --cm-link-bio-icon: <?php echo esc_attr( $icon ); ?>;">
							<span class="cm-link-bio__icon-box">
								<span class="cm-link-bio__icon">
									<?php if ( ! empty( $item['logo_image']['url'] ) ) : ?>
										<img class="cm-link-bio__custom-logo" src="<?php echo esc_url( $item['logo_image']['url'] ); ?>" alt="">
									<?php else : ?>
									<?php
									$cm_link_bio_title = isset( $item['title'] ) ? strtolower( trim( $item['title'] ) ) : '';

									if ( 'merch' === $cm_link_bio_title || false !== strpos( $cm_link_bio_title, 'merch' ) ) :
										?>
										<svg class="cm-link-bio__forced-shirt" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
											<path d="M22 8h8c1.4 2.7 5.2 2.7 6.6 0h8l13.4 8.8-6.5 12.6-6.5-3.1V56H21V26.3l-6.5 3.1L8 16.8 22 8z"/>
										</svg>
										<?php
									else :
										\Elementor\Icons_Manager::render_icon( $item['icon'], array( 'aria-hidden' => 'true' ) );
									endif;
									?>
									<?php endif; ?>
								</span>
							</span>
							<span class="cm-link-bio__text">
								<strong><?php echo esc_html( $item['title'] ); ?></strong>
								<small><?php echo esc_html( $item['subtitle'] ); ?></small>
							</span>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}

endif;
