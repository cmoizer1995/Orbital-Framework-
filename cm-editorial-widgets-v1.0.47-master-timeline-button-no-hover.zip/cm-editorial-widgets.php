<?php
/**
 * Plugin Name: CM Editorial Widgets
 * Description: Combined Elementor widgets with background social URL cards using thumbnails and buttons for TikTok, YouTube, Instagram and other platform links.
 * Version: 1.0.47
 * Author: Connor Moizer
 * Text Domain: cm-editorial-widgets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CM_EDITORIAL_WIDGETS_VERSION', '1.0.47' );
define( 'CM_EDITORIAL_WIDGETS_PATH', plugin_dir_path( __FILE__ ) );
define( 'CM_EDITORIAL_WIDGETS_URL', plugin_dir_url( __FILE__ ) );

final class CM_Editorial_Widgets_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_timeline_frontend_force' ), 99 );
		add_action( 'wp_head', array( $this, 'print_timeline_desktop_force_css' ), 9999 );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
	}

	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'cm-editorial-widgets',
			array(
				'title' => esc_html__( 'CM Widgets', 'cm-editorial-widgets' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	public function register_assets() {
		wp_register_style(
			'cm-laboratory-hero-widget',
			CM_EDITORIAL_WIDGETS_URL . 'assets/css/cm-laboratory-hero-widget.css',
			array(),
			CM_EDITORIAL_WIDGETS_VERSION
		);

		wp_register_style(
			'cm-featured-news-grid',
			CM_EDITORIAL_WIDGETS_URL . 'assets/css/cm-featured-news-grid.css',
			array(),
			CM_EDITORIAL_WIDGETS_VERSION
		);

		wp_register_style(
			'cm-link-bio-widget',
			CM_EDITORIAL_WIDGETS_URL . 'assets/css/cm-link-bio-widget.css',
			array(),
			CM_EDITORIAL_WIDGETS_VERSION
		);

		wp_register_style(
			'cm-timeline-widget',
			CM_EDITORIAL_WIDGETS_URL . 'assets/css/cm-timeline-widget.css',
			array(),
			CM_EDITORIAL_WIDGETS_VERSION
		);
	}

	public function enqueue_assets() {
		wp_register_style(
			'cm-timeline-widget',
			CM_EDITORIAL_WIDGETS_URL . 'assets/css/cm-timeline-widget.css',
			array(),
			CM_EDITORIAL_WIDGETS_VERSION
		);

		wp_enqueue_style( 'cm-laboratory-hero-widget' );
		wp_enqueue_style( 'cm-featured-news-grid' );
		wp_enqueue_style( 'cm-link-bio-widget' );
	}

	public function enqueue_timeline_frontend_force() {
		if ( wp_style_is( 'cm-timeline-widget', 'registered' ) ) {
			wp_enqueue_style( 'cm-timeline-widget' );
		}
	}

	public function print_timeline_desktop_force_css() {
		?>
		<style id="cm-timeline-desktop-force-v1047">
		.elementor-widget-cm_timeline,
		.elementor-widget-cm-timeline,
		.elementor-element.elementor-widget-cm_timeline,
		.elementor-element.elementor-widget-cm-timeline,
		.elementor-widget-cm_timeline .elementor-widget-container,
		.elementor-widget-cm-timeline .elementor-widget-container,
		.elementor-widget-cm_timeline .cm-timeline,
		.elementor-widget-cm-timeline .cm-timeline{display:block!important;visibility:visible!important;opacity:1!important;height:auto!important;max-height:none!important;overflow:visible!important}
		.elementor-widget-cm_timeline .cm-timeline__track,
		.elementor-widget-cm-timeline .cm-timeline__track,
		.elementor-widget-cm_timeline .cm-timeline__item,
		.elementor-widget-cm-timeline .cm-timeline__item{display:grid!important;visibility:visible!important;opacity:1!important;height:auto!important;max-height:none!important;overflow:visible!important}
		.elementor-widget-cm_timeline .cm-timeline__card,
		.elementor-widget-cm-timeline .cm-timeline__card,
		.elementor-widget-cm_timeline .cm-timeline__label,
		.elementor-widget-cm-timeline .cm-timeline__label,
		.elementor-widget-cm_timeline .cm-timeline__dot,
		.elementor-widget-cm-timeline .cm-timeline__dot{visibility:visible!important;opacity:1!important}
		@media (min-width:768px){.elementor-widget-cm_timeline,.elementor-widget-cm-timeline{display:block!important;visibility:visible!important;opacity:1!important;height:auto!important;max-height:none!important;overflow:visible!important}}
		</style>
		<?php
	}

	public function register_widgets( $widgets_manager ) {
		if ( ! did_action( 'elementor/loaded' ) || ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		require_once CM_EDITORIAL_WIDGETS_PATH . 'widgets/class-cm-laboratory-hero-widget.php';
		require_once CM_EDITORIAL_WIDGETS_PATH . 'widgets/class-cm-featured-news-grid-widget.php';
		require_once CM_EDITORIAL_WIDGETS_PATH . 'widgets/class-cm-link-bio-widget.php';
		require_once CM_EDITORIAL_WIDGETS_PATH . 'widgets/class-cm-timeline-widget.php';

		if ( class_exists( '\CM_Laboratory_Hero_Widget' ) ) {
			$widgets_manager->register( new \CM_Laboratory_Hero_Widget() );
		}

		if ( class_exists( '\CM_Featured_News_Grid_Widget' ) ) {
			$widgets_manager->register( new \CM_Featured_News_Grid_Widget() );
		}

		if ( class_exists( '\CM_Link_Bio_Widget' ) ) {
			$widgets_manager->register( new \CM_Link_Bio_Widget() );
		}

		if ( class_exists( '\CM_Timeline_Widget' ) ) {
			$widgets_manager->register( new \CM_Timeline_Widget() );
		}
	}
}


/**
 * Background Social URL Auto Embed
 *
 * Converts pasted social links inside normal post content into WordPress oEmbeds,
 * even when the link is pasted inside a sentence rather than on its own line.
 */
final class CM_Editorial_Social_URL_Auto_Embed {

	public function __construct() {
		add_filter( 'the_content', array( $this, 'convert_social_urls_to_buttons' ), 8 );
		add_filter( 'the_content', array( $this, 'force_social_embeds_to_linkbio_buttons' ), 999 );
	}

	private function allowed_hosts() {
		return array(
			'tiktok.com',
			'www.tiktok.com',
			'vm.tiktok.com',
			'vt.tiktok.com',
			'youtube.com',
			'www.youtube.com',
			'm.youtube.com',
			'youtu.be',
			'instagram.com',
			'www.instagram.com',
			'x.com',
			'www.x.com',
			'twitter.com',
			'www.twitter.com',
			'facebook.com',
			'www.facebook.com',
			'fb.watch',
			'vimeo.com',
			'www.vimeo.com',
		);
	}

	private function short_link_hosts() {
		return array(
			'vm.tiktok.com',
			'vt.tiktok.com',
			'youtu.be',
			'fb.watch',
		);
	}

	private function is_allowed_social_url( $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );

		if ( ! $host ) {
			return false;
		}

		return in_array( strtolower( $host ), $this->allowed_hosts(), true );
	}

	private function is_short_social_url( $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );

		if ( ! $host ) {
			return false;
		}

		return in_array( strtolower( $host ), $this->short_link_hosts(), true );
	}

	private function platform_name( $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

		if ( false !== strpos( $host, 'tiktok' ) ) {
			return 'TikTok';
		}

		if ( false !== strpos( $host, 'youtube' ) || false !== strpos( $host, 'youtu.be' ) ) {
			return 'YouTube';
		}

		if ( false !== strpos( $host, 'instagram' ) ) {
			return 'Instagram';
		}

		if ( false !== strpos( $host, 'twitter' ) || false !== strpos( $host, 'x.com' ) ) {
			return 'X';
		}

		if ( false !== strpos( $host, 'facebook' ) || false !== strpos( $host, 'fb.watch' ) ) {
			return 'Facebook';
		}

		if ( false !== strpos( $host, 'vimeo' ) ) {
			return 'Vimeo';
		}

		return 'Platform';
	}

	private function expand_short_url( $url ) {
		if ( ! $this->is_short_social_url( $url ) ) {
			return $url;
		}

		$response = wp_remote_head(
			$url,
			array(
				'timeout'     => 8,
				'redirection' => 5,
				'user-agent'  => 'Mozilla/5.0 WordPress CM Editorial Widgets',
			)
		);

		if ( is_wp_error( $response ) ) {
			$response = wp_remote_get(
				$url,
				array(
					'timeout'     => 8,
					'redirection' => 5,
					'user-agent'  => 'Mozilla/5.0 WordPress CM Editorial Widgets',
				)
			);
		}

		if ( is_wp_error( $response ) ) {
			return $url;
		}

		$final_url = '';

		if ( isset( $response['http_response'] ) && is_object( $response['http_response'] ) && method_exists( $response['http_response'], 'get_response_object' ) ) {
			$response_object = $response['http_response']->get_response_object();

			if ( ! empty( $response_object->url ) ) {
				$final_url = $response_object->url;
			}
		}

		if ( empty( $final_url ) ) {
			$location = wp_remote_retrieve_header( $response, 'location' );

			if ( ! empty( $location ) ) {
				$final_url = $location;
			}
		}

		$final_url = esc_url_raw( $final_url );

		if ( ! empty( $final_url ) && $this->is_allowed_social_url( $final_url ) ) {
			return $final_url;
		}

		return $url;
	}

	private function normalise_title_from_text( $text, $url ) {
		$text = wp_strip_all_tags( (string) $text );
		$text = preg_replace( '~https?://\S+~i', '', $text );
		$text = html_entity_decode( $text, ENT_QUOTES, get_bloginfo( 'charset' ) );
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );

		if ( empty( $text ) ) {
			return '';
		}

		// Common social-share cleanup.
		$text = preg_replace( '/\bwatch\s+the\s+full\s+video\s+now\b/i', '', $text );
		$text = preg_replace( '/\bcheck\s+out\s+this\s+(tiktok|youtube|instagram|video|post)\s+i\s+posted\b/i', '', $text );
		$text = preg_replace( '/[@#][a-z0-9_.-]+/i', '', $text );
		$text = str_replace( array( '▶️', '▶', '…', '...' ), ' ', $text );
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );

		// Prefer wording before "video" because posts often say "until it sleeps video".
		if ( preg_match( '/([a-z0-9][a-z0-9\s\'-]{2,80})\s+video\b/i', $text, $m ) ) {
			$text = trim( $m[1] );
		}

		// Clean common filler.
		$text = preg_replace( '/\b(full|now|watch|posted|music|video)\b$/i', '', $text );
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );

		if ( empty( $text ) ) {
			return '';
		}

		return ucwords( strtolower( $text ) );
	}

	private function title_from_url( $url ) {
		$expanded_url = $this->expand_short_url( $url );
		$path = trim( (string) wp_parse_url( $expanded_url, PHP_URL_PATH ), '/' );

		if ( empty( $path ) ) {
			return '';
		}

		$parts = explode( '/', $path );
		$slug = end( $parts );

		if ( ! $slug || is_numeric( $slug ) ) {
			return '';
		}

		$slug = preg_replace( '/[-_]+/', ' ', sanitize_title( $slug ) );
		$slug = trim( $slug );

		if ( empty( $slug ) ) {
			return '';
		}

		return ucwords( $slug );
	}

	private function get_social_oembed_data( $url ) {
		$cache_key = 'cm_editorial_social_oembed_' . md5( $url );
		$cached = get_transient( $cache_key );

		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : array();
		}

		$data = array();

		$oembed = _wp_oembed_get_object();

		if ( $oembed && method_exists( $oembed, 'get_data' ) ) {
			$response = $oembed->get_data( $url );

			if ( $response && is_object( $response ) ) {
				$data = (array) $response;
			}
		}

		set_transient( $cache_key, $data, DAY_IN_SECONDS );

		return $data;
	}

	private function get_thumbnail_from_social_url( $url ) {
		$expanded_url = $this->expand_short_url( $url );
		$data = $this->get_social_oembed_data( $expanded_url );

		if ( ! empty( $data['thumbnail_url'] ) ) {
			return esc_url_raw( $data['thumbnail_url'] );
		}

		if ( ! empty( $data['thumbnail_url_with_play_button'] ) ) {
			return esc_url_raw( $data['thumbnail_url_with_play_button'] );
		}

		return '';
	}

	private function get_title_from_social_data( $url ) {
		$expanded_url = $this->expand_short_url( $url );
		$data = $this->get_social_oembed_data( $expanded_url );

		if ( ! empty( $data['title'] ) ) {
			return wp_strip_all_tags( $data['title'] );
		}

		return '';
	}

	private function build_button( $url, $context_text = '' ) {
		$expanded_url = $this->expand_short_url( $url );
		$platform     = $this->platform_name_for_button( $expanded_url );
		$data         = $this->get_social_oembed_data( $expanded_url );

		$description = '';

		if ( ! empty( $data['title'] ) ) {
			$description = $data['title'];
		} elseif ( ! empty( $data['description'] ) ) {
			$description = $data['description'];
		} else {
			$description = $this->normalise_title_from_text( $context_text, $expanded_url );
		}

		if ( empty( $description ) ) {
			$description = $this->title_from_url( $expanded_url );
		}

		if ( empty( $description ) ) {
			$description = $expanded_url;
		}

		$description = wp_strip_all_tags( html_entity_decode( $description, ENT_QUOTES, get_bloginfo( 'charset' ) ) );
		$description = trim( preg_replace( '/\s+/', ' ', $description ) );

		if ( strlen( $description ) > 140 ) {
			$description = substr( $description, 0, 137 ) . '...';
		}

		$accent = $this->platform_colour_for_button( $platform, $expanded_url );
		$icon   = $this->platform_icon_for_button( $platform, $expanded_url );

		return sprintf(
			'<a class="cm-editorial-social-linkbio-button cm-editorial-social-linkbio-button--%6$s" href="%1$s" target="_blank" rel="noopener noreferrer" style="--cm-social-accent:%4$s"><span class="cm-editorial-social-linkbio-icon">%5$s</span><span class="cm-editorial-social-linkbio-text"><strong>%2$s</strong><small>%3$s</small></span></a>',
			esc_url( $expanded_url ),
			esc_html( $platform ),
			esc_html( $description ),
			esc_attr( $accent ),
			$icon,
			esc_attr( sanitize_title( $platform ) )
		);
	}


	private function platform_name_for_button( $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$host = preg_replace( '/^www\./', '', $host );

		if ( false !== strpos( $host, 'tiktok.com' ) ) {
			return 'TikTok';
		}

		if ( false !== strpos( $host, 'youtube.com' ) || false !== strpos( $host, 'youtu.be' ) ) {
			return 'YouTube';
		}

		if ( false !== strpos( $host, 'instagram.com' ) ) {
			return 'Instagram';
		}

		if ( false !== strpos( $host, 'twitter.com' ) || false !== strpos( $host, 'x.com' ) ) {
			return 'Twitter';
		}

		if ( false !== strpos( $host, 'facebook.com' ) || false !== strpos( $host, 'fb.watch' ) ) {
			return 'Facebook';
		}

		if ( false !== strpos( $host, 'amazon.' ) || false !== strpos( $host, 'amzn.to' ) || false !== strpos( $host, 'a.co' ) ) {
			return 'Amazon Finds';
		}

		if ( false !== strpos( $host, 'paypal.' ) || false !== strpos( $host, 'paypal.me' ) ) {
			return 'Donate';
		}

		if ( false !== strpos( $host, 'twitch.tv' ) ) {
			return 'Twitch';
		}

		if ( false !== strpos( $host, 'discord.' ) || false !== strpos( $host, 'discord.gg' ) ) {
			return 'Discord';
		}

		if ( false !== strpos( $host, 'vimeo.com' ) ) {
			return 'Vimeo';
		}

		$parts = explode( '.', $host );
		$name  = ! empty( $parts[0] ) ? $parts[0] : 'Link';

		return ucwords( str_replace( array( '-', '_' ), ' ', $name ) );
	}

	private function platform_colour_for_button( $platform, $url = '' ) {
		$key = strtolower( (string) $platform );

		if ( false !== strpos( $key, 'tiktok' ) ) {
			return '#00f2ea';
		}

		if ( false !== strpos( $key, 'youtube' ) ) {
			return '#ff0000';
		}

		if ( false !== strpos( $key, 'instagram' ) ) {
			return '#e1306c';
		}

		if ( false !== strpos( $key, 'twitter' ) || 'x' === $key ) {
			return '#1da1f2';
		}

		if ( false !== strpos( $key, 'facebook' ) ) {
			return '#1877f2';
		}

		if ( false !== strpos( $key, 'amazon' ) ) {
			return '#ff9900';
		}

		if ( false !== strpos( $key, 'donate' ) || false !== strpos( $key, 'paypal' ) ) {
			return '#0070ba';
		}

		if ( false !== strpos( $key, 'twitch' ) ) {
			return '#9146ff';
		}

		if ( false !== strpos( $key, 'discord' ) ) {
			return '#5865f2';
		}

		return '#ff2d55';
	}

	private function platform_icon_for_button( $platform, $url = '' ) {
		$key = strtolower( (string) $platform );

		if ( false !== strpos( $key, 'tiktok' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M16.6 5.1c.9 1.1 2 1.8 3.4 1.9v3.1c-1.3 0-2.5-.4-3.6-1.1v5.8c0 3-2.4 5.4-5.4 5.4S5.6 17.8 5.6 14.8s2.4-5.4 5.4-5.4c.4 0 .8 0 1.2.1v3.3c-.4-.1-.8-.2-1.2-.2-1.2 0-2.2 1-2.2 2.2s1 2.2 2.2 2.2 2.2-1 2.2-2.2V3.8h3.1c.1.5.2.9.3 1.3z"/></svg>';
		}

		if ( false !== strpos( $key, 'youtube' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M21.6 7.2s-.2-1.5-.8-2.1c-.8-.8-1.7-.8-2.1-.9C15.8 4 12 4 12 4s-3.8 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2.1-.8 2.1S2.2 9 2.2 10.8v1.7c0 1.8.2 3.6.2 3.6s.2 1.5.8 2.1c.8.8 1.9.8 2.4.9 1.7.2 6.4.2 6.4.2s3.8 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2.1.8-2.1s.2-1.8.2-3.6v-1.7c0-1.8-.2-3.6-.2-3.6zM10.1 14.9V8.7l5.9 3.1-5.9 3.1z"/></svg>';
		}

		if ( false !== strpos( $key, 'instagram' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M7 2h10c2.8 0 5 2.2 5 5v10c0 2.8-2.2 5-5 5H7c-2.8 0-5-2.2-5-5V7c0-2.8 2.2-5 5-5zm10 2H7C5.3 4 4 5.3 4 7v10c0 1.7 1.3 3 3 3h10c1.7 0 3-1.3 3-3V7c0-1.7-1.3-3-3-3zm-5 4.5c1.9 0 3.5 1.6 3.5 3.5s-1.6 3.5-3.5 3.5S8.5 13.9 8.5 12 10.1 8.5 12 8.5zm0 2C11.2 10.5 10.5 11.2 10.5 12s.7 1.5 1.5 1.5 1.5-.7 1.5-1.5-.7-1.5-1.5-1.5zM17 6.8c.7 0 1.2.5 1.2 1.2S17.7 9.2 17 9.2 15.8 8.7 15.8 8 16.3 6.8 17 6.8z"/></svg>';
		}

		if ( false !== strpos( $key, 'amazon' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M10.7 16.6c-2.9 0-5.2-1.8-5.2-4.7 0-3.1 2.8-4.7 6.8-4.7h1.4V6.1c0-1.1-.7-1.8-2-1.8-1.1 0-1.9.5-2.1 1.5H6.1C6.4 3.1 8.7 2 11.8 2c3.5 0 5.6 1.5 5.6 4.4v7.2c0 .9.1 1.8.3 2.7h-3.4c-.1-.5-.2-1-.2-1.5-.8 1.1-1.9 1.8-3.4 1.8zm1-2.6c1.2 0 2-.7 2-1.8V9.5h-1.2c-2.1 0-3.2.7-3.2 2.1 0 1.4 1 2.4 2.4 2.4zM5 19.5c4.4 2 9.2 2 13.6 0 .4-.2.8.3.4.7-3.8 3.3-10.4 3.3-14.3 0-.4-.4 0-.9.3-.7z"/></svg>';
		}

		if ( false !== strpos( $key, 'twitch' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M4 3h17v11l-5 5h-4l-3 3H7v-3H4V3zm3 3v10h4v3l3-3h4V6H7zm4 3h2v5h-2V9zm5 0h2v5h-2V9z"/></svg>';
		}

		if ( false !== strpos( $key, 'discord' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M19 5.5c-1.3-.6-2.7-1-4.1-1.2l-.5 1c-1.6-.2-3.2-.2-4.8 0l-.5-1C7.7 4.5 6.3 4.9 5 5.5c-2.6 3.9-3.3 7.7-3 11.4 1.7 1.2 3.3 2 4.9 2.5l1.1-1.8c-.6-.2-1.2-.5-1.7-.8l.4-.3c3.3 1.5 6.7 1.5 10.1 0l.4.3c-.5.3-1.1.6-1.7.8l1.1 1.8c1.7-.5 3.3-1.3 4.9-2.5.5-4.3-.7-8.1-2.5-11.4zM8.6 14.3c-.9 0-1.7-.8-1.7-1.8s.8-1.8 1.7-1.8 1.7.8 1.7 1.8-.8 1.8-1.7 1.8zm6.8 0c-.9 0-1.7-.8-1.7-1.8s.8-1.8 1.7-1.8 1.7.8 1.7 1.8-.8 1.8-1.7 1.8z"/></svg>';
		}

		if ( false !== strpos( $key, 'donate' ) || false !== strpos( $key, 'paypal' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M7.2 21H3.8L7.1 3h7.1c3.2 0 5.2 1.8 5.2 4.7 0 4.1-3.1 6.6-7.1 6.6H9L7.2 21zM9.5 11.5h2.7c2.2 0 3.5-1.2 3.5-3.1 0-1.4-.9-2.2-2.6-2.2h-3L9.5 11.5z"/></svg>';
		}

		return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M3.9 12c0-1.1.4-2.1 1.2-2.9l3.5-3.5c1.6-1.6 4.2-1.6 5.8 0 .5.5.5 1.2 0 1.7s-1.2.5-1.7 0c-.7-.7-1.8-.7-2.4 0L6.8 10.8c-.7.7-.7 1.8 0 2.4.7.7 1.8.7 2.4 0 .5-.5 1.2-.5 1.7 0s.5 1.2 0 1.7c-1.6 1.6-4.2 1.6-5.8 0-.8-.8-1.2-1.8-1.2-2.9z"/></svg>';
	}

	private function platform_colour_for_linkbio( $platform ) {
		$platform = strtolower( (string) $platform );

		if ( false !== strpos( $platform, 'tiktok' ) ) {
			return '#00f2ea';
		}

		if ( false !== strpos( $platform, 'youtube' ) ) {
			return '#ff0000';
		}

		if ( false !== strpos( $platform, 'instagram' ) ) {
			return '#e1306c';
		}

		if ( false !== strpos( $platform, 'twitter' ) || 'x' === $platform ) {
			return '#1da1f2';
		}

		if ( false !== strpos( $platform, 'facebook' ) ) {
			return '#1877f2';
		}

		if ( false !== strpos( $platform, 'vimeo' ) ) {
			return '#1ab7ea';
		}

		return '#ff2d55';
	}

	private function platform_icon_for_linkbio( $platform ) {
		$platform = strtolower( (string) $platform );

		if ( false !== strpos( $platform, 'tiktok' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M16.6 5.1c.9 1.1 2 1.8 3.4 1.9v3.1c-1.3 0-2.5-.4-3.6-1.1v5.8c0 3-2.4 5.4-5.4 5.4S5.6 17.8 5.6 14.8s2.4-5.4 5.4-5.4c.4 0 .8 0 1.2.1v3.3c-.4-.1-.8-.2-1.2-.2-1.2 0-2.2 1-2.2 2.2s1 2.2 2.2 2.2 2.2-1 2.2-2.2V3.8h3.1c.1.5.2.9.3 1.3z"/></svg>';
		}

		if ( false !== strpos( $platform, 'youtube' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M21.6 7.2s-.2-1.5-.8-2.1c-.8-.8-1.7-.8-2.1-.9C15.8 4 12 4 12 4s-3.8 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2.1-.8 2.1S2.2 9 2.2 10.8v1.7c0 1.8.2 3.6.2 3.6s.2 1.5.8 2.1c.8.8 1.9.8 2.4.9 1.7.2 6.4.2 6.4.2s3.8 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2.1.8-2.1s.2-1.8.2-3.6v-1.7c0-1.8-.2-3.6-.2-3.6zM10.1 14.9V8.7l5.9 3.1-5.9 3.1z"/></svg>';
		}

		if ( false !== strpos( $platform, 'instagram' ) ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M7 2h10c2.8 0 5 2.2 5 5v10c0 2.8-2.2 5-5 5H7c-2.8 0-5-2.2-5-5V7c0-2.8 2.2-5 5-5zm10 2H7C5.3 4 4 5.3 4 7v10c0 1.7 1.3 3 3 3h10c1.7 0 3-1.3 3-3V7c0-1.7-1.3-3-3-3zm-5 4.5c1.9 0 3.5 1.6 3.5 3.5s-1.6 3.5-3.5 3.5S8.5 13.9 8.5 12 10.1 8.5 12 8.5zm0 2C11.2 10.5 10.5 11.2 10.5 12s.7 1.5 1.5 1.5 1.5-.7 1.5-1.5-.7-1.5-1.5-1.5zM17 6.8c.7 0 1.2.5 1.2 1.2S17.7 9.2 17 9.2 15.8 8.7 15.8 8 16.3 6.8 17 6.8z"/></svg>';
		}

		return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M3.9 12c0-1.1.4-2.1 1.2-2.9l3.5-3.5c1.6-1.6 4.2-1.6 5.8 0 .5.5.5 1.2 0 1.7s-1.2.5-1.7 0c-.7-.7-1.8-.7-2.4 0L6.8 10.8c-.7.7-.7 1.8 0 2.4.7.7 1.8.7 2.4 0 .5-.5 1.2-.5 1.7 0s.5 1.2 0 1.7c-1.6 1.6-4.2 1.6-5.8 0-.8-.8-1.2-1.8-1.2-2.9z"/></svg>';
	}


	public function convert_social_urls_to_buttons( $content ) {
		if ( is_admin() || empty( $content ) || ! is_singular() ) {
			return $content;
		}

		if ( false === strpos( $content, 'http' ) ) {
			return $content;
		}

		$paragraph_pattern = '~(<p\b[^>]*>)(.*?)(</p>)~is';

		$content = preg_replace_callback(
			$paragraph_pattern,
			function( $paragraph ) {
				$open = $paragraph[1];
				$body = $paragraph[2];
				$close = $paragraph[3];

				if ( false === strpos( $body, 'http' ) ) {
					return $paragraph[0];
				}

				$url_pattern = '~(?<!["\'=])\bhttps?://[^\s<>()]+~i';

				$new_body = preg_replace_callback(
					$url_pattern,
					function( $matches ) use ( $body ) {
						$raw_url = trim( $matches[0] );
						$url = rtrim( $raw_url, ".,!?;:)]}" );

						if ( ! $this->is_allowed_social_url( $url ) ) {
							return $matches[0];
						}

						return $this->build_button( $url, $body );
					},
					$body
				);

				return $open . $new_body . $close;
			},
			$content
		);

		// Fallback for content without paragraph tags.
		$url_pattern = '~(?<!["\'=])\bhttps?://[^\s<>()]+~i';

		$content = preg_replace_callback(
			$url_pattern,
			function( $matches ) {
				$raw_url = trim( $matches[0] );
				$url = rtrim( $raw_url, ".,!?;:)]}" );

				if ( ! $this->is_allowed_social_url( $url ) ) {
					return $matches[0];
				}

				// Avoid converting URLs already inside the generated button.
				if ( false !== strpos( $matches[0], 'cm-editorial-social-button' ) ) {
					return $matches[0];
				}

				return $this->build_button( $url, '' );
			},
			$content
		);

		return $content;
	}

	public function force_social_embeds_to_linkbio_buttons( $content ) {
		if ( is_admin() || empty( $content ) || ! is_singular() ) {
			return $content;
		}

		// Force TikTok blockquote/embed output into a Link Bio button.
		$content = preg_replace_callback(
			'~<blockquote[^>]*class=["\\\'][^"\\\']*tiktok-embed[^"\\\']*["\\\'][\\s\\S]*?</blockquote>~i',
			function( $matches ) {
				$html = $matches[0];
				$url  = '';

				if ( preg_match( '~cite=["\\\']([^"\\\']+)["\\\']~i', $html, $m ) ) {
					$url = html_entity_decode( $m[1], ENT_QUOTES, get_bloginfo( 'charset' ) );
				} elseif ( preg_match( '~https?://[^\\s"\\\'<>]+~i', $html, $m ) ) {
					$url = $m[0];
				}

				if ( empty( $url ) ) {
					return $html;
				}

				return $this->build_button( $url, wp_strip_all_tags( $html ) );
			},
			$content
		);

		// Force large TikTok icon/card wrappers from previous plugin versions into Link Bio buttons.
		$content = preg_replace_callback(
			'~<a[^>]+href=["\\\'](https?://(?:www\\.)?(?:tiktok\\.com|vm\\.tiktok\\.com|vt\\.tiktok\\.com)[^"\\\']+)["\\\'][\\s\\S]*?</a>~i',
			function( $matches ) {
				$url = html_entity_decode( $matches[1], ENT_QUOTES, get_bloginfo( 'charset' ) );
				return $this->build_button( $url, wp_strip_all_tags( $matches[0] ) );
			},
			$content
		);

		// Force standalone raw URLs that were not inside paragraphs.
		$content = preg_replace_callback(
			'~(?<!["\\\'=])\\bhttps?://[^\\s<>()]+~i',
			function( $matches ) {
				$raw = trim( $matches[0] );
				$url = rtrim( $raw, '.,!?;:)]}' );

				if ( ! $this->is_allowed_social_url( $url ) && ! $this->is_known_button_url( $url ) ) {
					return $matches[0];
				}

				return $this->build_button( $url, '' );
			},
			$content
		);

		return $content;
	}

	private function is_known_button_url( $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		return (
			false !== strpos( $host, 'amazon.' ) ||
			false !== strpos( $host, 'amzn.to' ) ||
			false !== strpos( $host, 'a.co' ) ||
			false !== strpos( $host, 'paypal.' ) ||
			false !== strpos( $host, 'paypal.me' ) ||
			false !== strpos( $host, 'twitch.tv' ) ||
			false !== strpos( $host, 'discord.' ) ||
			false !== strpos( $host, 'discord.gg' )
		);
	}

}

new CM_Editorial_Social_URL_Auto_Embed();


CM_Editorial_Widgets_Plugin::instance();
