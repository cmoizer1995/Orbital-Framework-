# Cm Featured News Grid Widget

Standalone plugin split from CM Editorial Widgets master plugin.
