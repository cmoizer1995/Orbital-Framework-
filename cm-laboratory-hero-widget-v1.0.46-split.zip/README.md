# Cm Laboratory Hero Widget

Standalone plugin split from CM Editorial Widgets master plugin.
