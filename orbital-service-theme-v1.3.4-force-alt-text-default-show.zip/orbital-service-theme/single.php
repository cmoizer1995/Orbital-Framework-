<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

get_header();
?>
<section class="ost-content-shell">
  <div class="ost-main-content ost-layout <?php echo esc_attr(function_exists('ost_layout_sidebar_position_class') ? ost_layout_sidebar_position_class() : 'ost-layout-sidebar-right'); ?>">
    <div class="ost-main">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php
          $ost_post_type = get_post_type();
          $ost_is_elementor_content = (bool) get_post_meta(get_the_ID(), '_elementor_edit_mode', true);
          $ost_blog_flow_types = array(
            'post', 'posts', 'blog', 'blogs', 'news', 'article', 'articles',
            'live_blog', 'live-blog', 'live_blogs', 'live-blogs',
            'portfolio', 'portfolios', 'project', 'projects', 'work', 'works',
            'review', 'reviews', 'case_study', 'case-study', 'case_studies', 'case-studies',
            'cv', 'cvs', 'resume', 'resumes', 'curriculum_vitae', 'curriculum-vitae'
          );
          $ost_blog_flow_subsite_terms = array('blog', 'blogs', 'post', 'posts', 'news', 'article', 'articles', 'live blog', 'live-blog', 'live blogs', 'live-blogs', 'cv', 'cvs', 'resume', 'resumes', 'curriculum vitae', 'curriculum-vitae');
          $ost_current_site_check = strtolower(trim(wp_strip_all_tags(get_bloginfo('name') . ' ' . home_url('/'))));
          $ost_is_blog_flow_subsite = false;
          foreach ($ost_blog_flow_subsite_terms as $ost_blog_flow_subsite_term) {
            if (strpos($ost_current_site_check, $ost_blog_flow_subsite_term) !== false) {
              $ost_is_blog_flow_subsite = true;
              break;
            }
          }
          $ost_entry_classes = 'ost-entry';
          if (!$ost_is_elementor_content && (in_array($ost_post_type, $ost_blog_flow_types, true) || ($ost_is_blog_flow_subsite && $ost_post_type !== 'page'))) {
            $ost_entry_classes .= ' ost-blog-flow';
          }
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class($ost_entry_classes); ?>>
          <?php
            /* If the global page-title area is switched off, keep the editorial meta inside the post layout. */
            if (function_exists('ost_is_blog_style_post_type') && ost_is_blog_style_post_type($ost_post_type) && (!function_exists('ost_show_page_title_for_current_context') || !ost_show_page_title_for_current_context())) :
          ?>
            <header class="ost-entry-editorial-header">
              <h1 class="ost-entry-title"><?php the_title(); ?></h1>
              <?php ost_itv_datetime_author_meta(get_the_ID(), 'full'); ?>
            </header>
          <?php endif; ?>
          <div class="entry-content">
            <?php the_content(); ?>
            <?php wp_link_pages(array('before'=>'<div class="page-links">','after'=>'</div>')); ?>
          </div>
        </article>
      <?php endwhile; endif; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</section>
<?php
get_footer();
