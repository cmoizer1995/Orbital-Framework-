<?php
$post_type = function_exists('ost_current_post_type_slug') ? ost_current_post_type_slug() : '';
$position  = function_exists('ost_get_cpt_widget_position') ? ost_get_cpt_widget_position($post_type) : 'right';

ob_start();
$rendered = false;

if (function_exists('ost_should_show_cpt_widgets') && ost_should_show_cpt_widgets($post_type) && function_exists('ost_dynamic_cpt_sidebar_rendered')) {
    $rendered = ost_dynamic_cpt_sidebar_rendered($post_type);
}

if (!$rendered && function_exists('ost_cpt_widget_fallback_enabled') && ost_cpt_widget_fallback_enabled() && function_exists('ost_is_blog_style_post_type') && ost_is_blog_style_post_type($post_type)) {
    the_widget('OST_ITV_Related_CPT_Posts_Widget', array(
        'title' => 'Related News',
        'mode' => 'auto',
        'manual_post_type' => 'post',
        'number' => 3,
        'order' => 'date_desc',
    ), array(
        'before_widget' => '<section class="widget ost-default-related-widget">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
    $rendered = true;
}

if (!$rendered && function_exists('ost_cpt_widget_fallback_enabled') && ost_cpt_widget_fallback_enabled()) :
?>
<section class="widget"><h2 class="widget-title">Mission links</h2><ul><li><a href="#overview">Overview</a></li><li><a href="#updates">Latest updates</a></li><li><a href="#systems">Technology</a></li></ul></section>
<?php
    $rendered = true;
endif;

$sidebar_content = trim(ob_get_clean());
if (!$rendered || $sidebar_content === '') {
    return;
}
?>
<aside class="ost-sidebar <?php echo esc_attr('ost-sidebar-position-' . $position); ?>" aria-label="<?php esc_attr_e('Sidebar','orbital-service-theme'); ?>">
    <?php echo $sidebar_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</aside>
