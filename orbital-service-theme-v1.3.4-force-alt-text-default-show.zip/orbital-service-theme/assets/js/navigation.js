/*
 * Orbital Service Theme
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

(function () {
  'use strict';

  function closePanel(toggle, panel) {
    if (!toggle || !panel) return;
    toggle.setAttribute('aria-expanded', 'false');
    panel.classList.remove('is-open');
  }

  function bindPanelToggle(toggleSelector, panelSelector) {
    var toggle = document.querySelector(toggleSelector);
    var panel = document.querySelector(panelSelector);
    if (!toggle || !panel) return;

    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
      panel.classList.toggle('is-open', !open);
    });
  }

  function bindSubmenuToggles() {
    document.querySelectorAll('.ost-submenu-toggle').forEach(function (button) {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();

        var li = button.closest('li');
        if (!li) return;

        var open = li.classList.contains('is-open');
        li.classList.toggle('is-open', !open);
        button.setAttribute('aria-expanded', open ? 'false' : 'true');
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    bindPanelToggle('.ost-mobile-toggle', '#ost-primary-nav');
    bindPanelToggle('.ost-service-mobile-toggle', '#ost-service-nav');
    bindSubmenuToggles();
  });
}());
