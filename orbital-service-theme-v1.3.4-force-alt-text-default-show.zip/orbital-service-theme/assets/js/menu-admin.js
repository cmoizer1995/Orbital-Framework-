/*
 * Orbital Service Theme
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */


(function($){
  function activePanel($box){
    return $box.find('.ost-menu-site-panel.is-active');
  }
  $(document).on('click', '.ost-menu-site-tab', function(e){
    e.preventDefault();
    var $tab = $(this);
    var $box = $tab.closest('.ost-menu-admin-box');
    var site = $tab.data('ost-site-tab');
    $box.find('.ost-menu-site-tab').removeClass('is-active');
    $tab.addClass('is-active');
    $box.find('.ost-menu-site-panel').removeClass('is-active tabs-panel-active').addClass('tabs-panel-inactive');
    $box.find('.ost-menu-site-panel[data-ost-site-panel="' + site + '"]').removeClass('tabs-panel-inactive').addClass('is-active tabs-panel-active');
  });
  $(document).on('change', '.ost-menu-post-type-filter', function(){
    var $select = $(this);
    var val = $select.val();
    var $panel = $select.closest('.ost-menu-site-panel');
    $panel.find('.ost-menu-content-item').each(function(){
      var $item = $(this);
      var show = val === 'all' || $item.data('ost-post-type') === val;
      $item.toggleClass('is-hidden', !show);
    });
  });
  $(document).on('click', '.ost-menu-select-all', function(e){
    e.preventDefault();
    var $box = $(this).closest('.ost-menu-admin-box');
    activePanel($box).find('.ost-menu-content-item:not(.is-hidden) .menu-item-checkbox').prop('checked', true);
  });


  /*
   * v1.0.83 fix:
   * WordPress core only serializes inputs from .tabs-panel-active inside custom
   * nav-menu meta boxes. Our multisite panels used only .is-active, so the
   * boxes could be ticked but Add to Menu did not receive the selected items.
   * Keep WP's native active panel class synced and temporarily disable inputs
   * outside the visible panel so only the chosen tab is submitted.
   */
  $(document).on('submit', '#nav-menu-meta', function(){
    $('.ost-menu-admin-box').each(function(){
      var $box = $(this);
      var $active = activePanel($box);
      $box.find('.ost-menu-site-panel').not($active).find(':input').prop('disabled', true);
      $active.addClass('tabs-panel-active').removeClass('tabs-panel-inactive');
      $active.find('.ost-menu-content-item.is-hidden :input').prop('disabled', true);
    });
  });
})(jQuery);
