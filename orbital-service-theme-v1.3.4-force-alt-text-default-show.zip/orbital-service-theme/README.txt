Version 1.3.2: Hard-forced automatic Media Library text under real article images using both Gutenberg render_block and the_content fallbacks. Real WordPress attachment images now pull Caption, Alt Text, Description, then Title, while emoji/smilies/icons are ignored.

Version 1.3.0: Forces only real uploaded WordPress content images to centre on single article content while excluding emoji/smilies so inline hearts and emoji stay inline.

Version 1.2.9: Hard-forced images inside single article content to centre on the front end, overriding editor left/right alignment and WordPress float classes while leaving headers, widgets and related post thumbnails alone.

Version 1.2.7: Reduced the Page Last Updated / Page Editor / Responsible Site Owner footer meta to match the copyright footer sizing and calmer weight.

Version 1.2.5: Fixed missing ost_content_height_mode() helper that caused a fatal error on the front end. Theme content height now safely defaults to Elementor Default so content finishes naturally unless Theme Fixed Height is selected.

Version 1.2.4: Added Customizer > Orbital Service Theme > Layout > Theme content height. Elementor Default is now the default and removes the old fixed 1440px theme content-height system so Elementor widgets/sections finish naturally underneath each other. Theme Fixed Height restores the old content-height behaviour if you want the theme to push the footer down.

== v1.1.8 ==
- Kept the v1.1.6 rollback/manual CPT widget system intact.
- Re-added the blog-style content flow only for blog/news/post/article/live-blog/portfolio/project/work/review-style single content.
- Normal pages, Home, Contact, About, service pages and Elementor-built content are not changed by the blog flow styling.
- Page title, header, service header, mission header and widget systems are not touched by this content-flow update.

== v1.1.6 ==
- Rolled back the widget changes made after the stable manual CPT widget system.
- Removed the automatic related-widget direction from the active workflow. Widgets are manual only again.
- Kept CPT listener support for built-in post types, CPT UI post types, third-party plugin CPTs and multisite CPTs.
- Kept real Appearance > Widgets areas for each detected CPT.
- Kept per-CPT On/Off controls, desktop left/right controls and mobile above-footer behaviour.
- Kept full-width layout when a CPT widget area is Off or empty.
- Removed the newer NASA-style widget direction and preview placeholder direction from this rollback build.


== v1.0.96 ==
- Automatic CPT Related Posts widget now uses the broad CPT listener instead of only hard-coded blog/portfolio names.
- Works for public/queryable CPT UI and third-party post types such as Work, Reviews, Projects, Portfolio, Blog, News and similar custom content.
- Multisite compatible: each subsite uses its own registered CPTs and can display related content for matching CPTs across public subsites.
- Standard pages and Home/Contact/About pages remain excluded.
- Manual CPT widget areas and fallback widgets remain off by default while the pre-made CPT Related Posts widget remains on by default.

Orbital Service Theme v1.0.88
==============================

v1.0.92 fixes mobile CPT widget output so the current CPT widget area renders above the footer on phones/tablets while desktop keeps the left/right sidebar layout.

v1.0.88 fixes the CPT listener for independent widget areas so it no longer only relies on public post types. It now detects built-in content types, CPT UI types, and third-party plugin CPTs registered with show_ui, public, publicly_queryable, show_in_menu, show_in_nav_menus or has_archive. Internal WordPress/template/form post types remain excluded so they do not clutter widget controls.

Orbital Service Theme
Version 1.0.86

Version 1.0.86: Added Multisite Content to the front-end Customizer menu item picker. Appearance > Customize > Menus > Add Items now includes network content as custom absolute links, so content from any public subsite can be added from the Customizer and then synced through the existing global header menu sync.

Author: Connor Moizer
Author URI: https://connormoizer.com
Version 1.0.85: Global header menu sync now also works from the front-end WordPress Customizer menu options. Menu item edits, added items, removed items, reordered items, dropdown changes and location assignment changes made in Customizer are scheduled for the same final network sync across all public multisite sites.

Copyright © Connor Moizer. All rights reserved.

Version 1.0.84: Global header menu sync is now two-way from any multisite. Editing titles, URLs, order, parent/child dropdowns, classes, targets or menu items on any site schedules a final sync after WordPress finishes saving, then copies the rendered menu to every public site.

Version 1.0.75: Fixed multisite menu syncing so copied menu items keep the original source-site URL and are stored as custom links, preventing red/invalid menu items on target subsites.

Version 1.0.74: Added proper author, author profile link, and copyright ownership headers across the theme files, including PHP, CSS, JavaScript, WordPress theme header metadata, and README documentation.

Orbital Service Theme
Version 1.0.71

Version 1.0.71: Home page now has its own service/mission header Display Rules checkbox. The service header is on by default for Home, pages and CPTs, and the Home checkbox can turn it off without affecting other content types.

- Restored service/mission header to be ON by default across pages, posts, blogs, live blogs and CPTs.
- Display Rules checkbox now always controls the service header: ticked shows it, unticked hides it.
- Removed the old forced blog/live-blog bypass so those CPTs can also be switched off when needed.
Orbital Service Theme v1.0.66

Orbital Service Theme v1.0.28

Changes:
- Main header site title/logo now use the multisite radio URL selector.
- On multisite, the selector lists detected network sites plus current, network and custom URL.
- Service title header remains local/site-only and still follows the CPT display/link rules.
- Service title dropdown now only links to content from the current CPT/current site.
- Smart main title rule preserved: 1-2 words show full title, 3+ words show initials.


Version 1.0.29
- Added embedded Appearance > Menus multisite content picker.
- Shows current/single site or all public multisite sites in tabs.
- Includes a content type dropdown filter and Add to Menu support using correct site URLs.


Version 1.0.31
- Added multisite detection mode in Customizer > Multisite Options.
- Auto detects WordPress multisite.
- Adds Force ON / Force OFF switch for multisite-style controls on single-site installs.


== v1.0.34 ==
- Enables the service/mission header on posts, blog/blogs, live blog/live blogs and archive-style blog sections.
- Keeps live-blog plugin functionality untouched; this is layout/header support only.
- Preserves the existing ITV-style date/time metadata row.


v1.0.39
- Forces the service/mission header onto any CPT whose slug/label/rewrite/archive name is post, posts, blog, blogs, live blog or live blogs.
- Keeps live blog/plugin content untouched; only the theme header/layout detection changed.


v1.0.39
- Search results now listen to the same public CPT system on single-site and multisite.
- Results are split into tabs, with one tab per content type that has matches.
- Each result keeps title, description, posted date/time under the title, and dividers between items.
- Search layout only is changed; post content and live-blog/plugin output are not modified.


= 1.0.39 =
* Search now scans every enabled multisite blog for CPTs whose slug/name/label/rewrite/archive exactly matches post, posts, blog, blogs, live blog or live blogs before building the tabs.


v1.0.39: Search now forces Hello-world/native-style behaviour across the whole multisite network for matching CPT names: post/posts, blog/blogs, live blog/live blogs, live-blog/live-blogs, live_blog/live_blogs, liveblog/liveblogs. Multisite network search no longer depends on the theme multisite switch being enabled.


Version 1.0.42
- Search now reuses the same post/blog/live-blog CPT listener as the service/mission header.
- Search results are grouped into CPT tabs across single-site and multisite installs.
- Native main search query is forced to include matching CPTs on the current site, while the search template also queries every public network site.


Version 1.0.42
- Rebuilt search as a tab-first content finder.
- Search page now shows matching CPT tabs before a term is entered.
- Search filters those same tabs down after submitting a term.
- Added This site / All sites scope switch for multisite installs.
- CPT listener includes post, posts, blog, blogs, live blog and live blogs style CPT names using the service/mission header matching rules.

Version 1.0.43
- Search tabs now merge similar CPTs into grouped tabs: Blog, Live Blog, and Posts.
- Blog + Blogs are shown under one Blog tab.
- Live Blog + Live Blogs + liveblog-style CPTs are shown under one Live Blog tab.
- Post + Posts are shown under one Posts tab.


Version 1.0.46
- Added Reset button beside This site / All sites to refresh the search page back to the unfiltered tab view.
- Added per-tab Load More button so each grouped CPT tab starts with the first 10 posts and keeps revealing more posts in batches.
- Search still uses the same grouped CPT listener for Blog, Blogs, Live Blog, Live Blogs, Post and Posts across single-site and multisite.


Version 1.0.46
- Search tabs now discover public plugin/theme registered CPTs across this site and multisite.
- Adds tabs for CPTs such as CV and Portfolio, while keeping Blog, Live Blog and Posts grouped together.
- Similar singular/plural CPT names are grouped into one tab.


Version 1.0.46
- Adds Pages to the tabbed search across this site and all multisite sites.
- Pages are grouped into their own Pages tab and work with search/filter, counts, reset, and load more.

Version 1.0.47
- Search tabs now exclude Dashboard, Forms, Test and Work CPT tabs.
- Multisite search now removes empty site groups from each tab before rendering.
- Keeps Pages, Posts, Blog, Live Blog, CV, Portfolio and other useful public CPT tabs.


Version 1.0.49
- Search load more now hides multisite site headings/site groups until content from that site is actually visible.
- Keeps excluded tabs and empty-site removal from v1.0.47.


Version 1.0.49
- Added individual multisite site tabs beside This site / All sites / Reset. Each site tab searches and displays only that site while keeping the grouped CPT/page tabs, filtering, and load more behaviour.

= 1.0.50 =
- Removed the This site scope button from the search page controls while keeping All sites, individual site tabs, Reset, CPT tabs and load more.

Version 1.0.55
- Properly fixed the search page Reset control so it uses the current search page URL/path instead of home_url('/').
- Search form action now posts back to the current search page URL and preserves individual site scope when a site tab is active.


v1.0.56
- Reset button on the search page now uses the requested custom search reset URL format: /3/?s&ost_scope=multi.

Version 1.0.58
- Reset button on the search page now performs a browser refresh of the current page instead of using a home-page or hard-coded reset URL.
- Main header Search button is now also visible inside the mobile menu, matching desktop behaviour.

Version 1.0.59
- Reset button on the search page now clears the search input and triggers the Search button/form submit instead of refreshing the browser.


v1.0.66
- Removed the main header centre logo/brand mark.
- Main header title now always shows the full site name instead of initials when the logo is not visible.


Version 1.0.67
- Main header Search link now points exactly to https://connormoizer.com/3/?s via home_url('/3/?s') with no extra search scope parameters.


Version 1.0.69
- Added Appearance > Menus > Sync Menus to All Sites.
- Copies the current site Global header menu to every public multisite sub site.
- Assigns the copied menu to the Global header menu location so the main header menu does not need recreating on each sub site.


Version 1.0.69: Main header menu sync now runs automatically when the normal WordPress Save Menu / Update Menu button is clicked. The separate manual sync button has been removed.


= v1.0.72 =
- Added Home page title toggle in CPT Display Rules.
- Home pages can now show or hide the normal page title banner independently from the service/mission header.


v1.0.74
- Added Main header title source option: Current Site Title, Main Network Site Title, or Custom Title.
- Lets multisite subsites show the main site title in the global header while keeping service/mission title independent.


v1.0.75
- Multisite menu sync now copies every item as a custom absolute link.
- Internal links stay pointing to the source site they came from.
- Page/Post/CPT menu items no longer turn red or invalid on subsites where the original object ID does not exist.
- Existing Save/Create/Update menu workflow is unchanged; no extra sync button added.


== v1.0.76 ==
- Header Search link now always points to the main site search URL: https://connormoizer.com/?s.
- 404 pages now keep the broken URL visible and render the shared main-site styled 404 layout across multisite.
- 404 home/search actions point back to the main site instead of the subsite.


Version 1.0.81
- Page/CPT titles are now rendered automatically directly after the main header/service header and before the content area.
- This forces the normal page title above Elementor-built content for pages, posts and registered CPTs while still respecting the existing Show page title checkboxes.


Version 1.0.87 - Independent CPT Widget Areas
- Added automatic CPT listener widget areas for built-in post types, plugin post types and CPT UI registered post types.
- Each detected public CPT now gets its own Dashboard > Appearance > Widgets area named CPT Widgets: [CPT Name].
- Added Customizer > Orbital Service Theme > CPT Widget Areas with on/off radio controls per content type.
- Sidebar rendering now uses the current CPT independent widget area first, falls back to the shared sidebar if the CPT area is empty, and still keeps the existing related-news fallback for blog-style CPTs.
- Turning a CPT widget area off hides widgets for that content type only and does not affect other CPTs.


= v1.0.89 =
* Fixed CPT widget areas so every detected built-in, CPT UI and third-party post type registers a real Appearance > Widgets sidebar area.
* Added late admin/customizer registration safety net for plugins that register CPTs after normal load order.
* Widget areas now appear as Orbital CPT Widgets — Post Type Name and remain independently controllable per CPT.


Version 1.0.91
- Fixed CPT widget display output on the front end.
- CPT widget areas now render on Pages, Posts, archives and detected CPT templates.
- Added per-CPT desktop position controls: Left or Right.
- Mobile always forces CPT widgets underneath the content.


Version 1.0.91
- Restored and strengthened On/Off controls for every detected CPT widget area.
- Added Appearance > Orbital CPT Widget Areas admin page so built-in, CPT UI and third-party plugin CPT widgets can always be switched on/off even when plugin CPTs register late.
- Kept v1.0.90 desktop left/right and mobile-bottom display behaviour.


== v1.0.92 ==
- Fixed mobile CPT widget placement so enabled CPT widgets output after content and above the footer.
- Desktop still uses the per-CPT left/right sidebar setting.
- Mobile hides the in-grid sidebar and uses a dedicated above-footer render point to prevent duplicate widgets.


Version 1.0.94
- Added a global CPT widget fallback On/Off control.
- In multisite, fallback widget mode is saved network-wide so all subsites follow the same fallback state.
- When fallback widgets are Off, only the current site's matching CPT widget area can render. Shared fallback sidebar widgets, default related/mission widgets, and main-site multisite widget fallbacks are skipped.

== v1.0.95 ==
- Normal/manual CPT widget areas now default to Off instead of On.
- Shared fallback widgets now default to Off network-wide.
- Added a pre-made automatic CPT Related Posts widget that remains On by default.
- Automatic related widget displays only on single content items whose post type looks like blog, posts, news, articles, portfolio, projects, case studies or work.
- Automatic related widget is hidden from Home, Contact, About Me, archive/search/404 and normal static pages.
- Related widget scans the current multisite network and can pull matching CPT items from subsites where the same CPT exists.
- Added a network-aware Customizer/Admin toggle for the pre-made CPT Related Posts widget.


== v1.0.98 ==
- Removed automatic/pre-made CPT Related Posts output from the front end.
- Related CPT Posts is now manual-only: add it yourself through Appearance > Widgets inside the matching Orbital CPT Widgets area.
- Manual CPT widget areas, CPT listener, CPT UI/third-party CPT support, multisite CPT detection, per-CPT On/Off controls, desktop Left/Right positioning and mobile above-footer rendering remain in place.
- The old automatic related widget setting is forced Off as a backwards-compatible no-op so older saved options cannot make it appear again.


## v1.0.98
- Fixed CPT widget Off layout so disabling a CPT widget area now removes the sidebar grid and returns content to full width.
- If a CPT widget area is enabled but empty, the page also stays full-width instead of reserving blank sidebar space.
- The full-width/no-sidebar check works the same in single-site and multisite mode, including the network fallback setting.


== v1.0.99 ==
- Fixed CPT widget On/Off controls so they control both rendering and full-width layout.
- Added network-aware CPT widget mode and desktop position storage for multisite.
- Customizer CPT widget settings now sync to the network option store after publish.
- When a CPT widget area is Off, the sidebar is not rendered and content returns to 100% width.


== v1.1.8 ==
- Kept scoped blog-style spacing/typography for blog and portfolio-style singles.
- Removed the narrow article width cap so content stretches like the normal full-width layout.
- Page title, header, service header, Elementor content, and widget rollback remain untouched.


== v1.1.9 ==
* Added CV/resume support to the scoped stretched blog-flow layout.
* Blog-flow styling now applies to CV-style CPTs: cv, cvs, resume, resumes, curriculum_vitae and curriculum-vitae.
* Blog-flow styling also applies on CV/resume/curriculum vitae subsites for non-page single content.
* Widgets, page title, header and service header systems are unchanged.


== v1.2.3 ==
- Moved all individual CPT controls into one Customizer tab: Individual CPT Controls.
- Main Orbital panel no longer lists every detected CPT as separate rows.
- Kept per-CPT service header, page title, widget, position, title mode, custom title/subtitle and service link controls.
