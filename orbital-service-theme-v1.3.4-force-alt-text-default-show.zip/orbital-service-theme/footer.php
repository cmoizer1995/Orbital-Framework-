</main>
<?php if (function_exists('ost_render_mobile_cpt_widgets_above_footer')) { ost_render_mobile_cpt_widgets_above_footer(); } ?>
<?php
$ost_footer_post_id = 0;
if (is_singular()) {
    $ost_footer_post_id = get_queried_object_id();
} elseif (is_home()) {
    $ost_footer_post_id = (int) get_option('page_for_posts');
}

$ost_footer_updated = get_theme_mod('ost_footer_updated_value', 'May 27, 2026');
$ost_footer_owner   = get_theme_mod('ost_footer_official_value', 'Connor Moizer');
$ost_footer_editor  = get_theme_mod('ost_footer_editor_value', 'Connor Moizer');

if ($ost_footer_post_id) {
    // Use the published date so manual changes to the Published on date update this footer line.
    $ost_footer_updated = get_the_date('F j, Y', $ost_footer_post_id);

    $ost_owner_id = (int) get_post_field('post_author', $ost_footer_post_id);
    $ost_owner_user = $ost_owner_id ? get_userdata($ost_owner_id) : false;
    if ($ost_owner_user) {
        $ost_footer_owner = $ost_owner_user->display_name;
    }

    $ost_editor_id = (int) get_post_meta($ost_footer_post_id, '_edit_last', true);
    if (!$ost_editor_id) {
        $ost_editor_id = $ost_owner_id;
    }
    $ost_editor_user = $ost_editor_id ? get_userdata($ost_editor_id) : false;
    if ($ost_editor_user) {
        $ost_footer_editor = $ost_editor_user->display_name;
    }
}
?>
<footer class="ost-footer ost-connor-meta-footer" role="contentinfo">
  <div class="ost-connor-footer-wrap">
    <p class="ost-connor-footer-line">
      <span class="ost-connor-footer-label"><?php echo esc_html(get_theme_mod('ost_footer_updated_label', 'Page Last Updated:')); ?></span>
      <strong><?php echo esc_html($ost_footer_updated); ?></strong>
    </p>
    <p class="ost-connor-footer-line">
      <span class="ost-connor-footer-label"><?php echo esc_html(get_theme_mod('ost_footer_editor_label', 'Page Editor:')); ?></span>
      <strong><?php echo esc_html($ost_footer_editor); ?></strong>
    </p>
    <p class="ost-connor-footer-line">
      <span class="ost-connor-footer-label"><?php echo esc_html(get_theme_mod('ost_footer_official_label', 'Responsible Site Owner:')); ?></span>
      <strong><?php echo esc_html($ost_footer_owner); ?></strong>
    </p>
  </div>

  <div class="ost-cmuk-credit-footer" aria-label="Site copyright and credit">
    <div class="ost-cmuk-credit-wrap">
      <?php
      $site_name_full = trim(get_bloginfo('name'));
      if ($site_name_full === '') {
          $site_name_full = parse_url(home_url('/'), PHP_URL_HOST);
      }
      $credit_url = trim(get_theme_mod('ost_footer_credit_url', 'https://connormoizer.com/'));
      if ($credit_url === '') {
          $credit_url = home_url('/');
      }
      ?>
      <span class="ost-cmuk-credit-copy">&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html($site_name_full); ?></span>
      <span class="ost-cmuk-credit-separator" aria-hidden="true">|</span>
      <span class="ost-cmuk-credit-made">Made with love by <a href="<?php echo esc_url($credit_url); ?>">Connor Moizer</a></span>
    </div>
  </div>
</footer>
</div>
<?php wp_footer(); ?>
</body></html>
