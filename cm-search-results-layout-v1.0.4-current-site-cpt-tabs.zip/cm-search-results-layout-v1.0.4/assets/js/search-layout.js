document.addEventListener('DOMContentLoaded', function () {

  document.querySelectorAll('.cm-srl-reset-tab').forEach(function (button) {
    button.addEventListener('click', function (event) {
      event.preventDefault();
      var form = document.querySelector('.cm-srl-form') || document.querySelector('form.search-form');
      document.querySelectorAll('.cm-srl-field, form.search-form input[name="s"]').forEach(function (input) { input.value = ''; });
      if (form) {
        var submit = form.querySelector('button[type="submit"], input[type="submit"]');
        if (form.requestSubmit) { form.requestSubmit(submit || undefined); }
        else if (submit) { submit.click(); }
        else { form.submit(); }
      }
    });
  });

  function setupLoadMore(panel) {
    var items = Array.prototype.slice.call(panel.querySelectorAll('[data-cm-srl-load-item]'));
    var button = panel.querySelector('[data-cm-srl-load-more]');
    var wrap = panel.querySelector('[data-cm-srl-load-more-wrap]');
    var initialItems = Math.min(parseInt(panel.getAttribute('data-cm-srl-initial') || '10', 10) || 10, 10);
    var stepItems = Math.min(parseInt(panel.getAttribute('data-cm-srl-step') || '10', 10) || 10, 10);
    if (!items.length) { return; }
    if (!button || !wrap) { return; }

    function shownCount() { return items.filter(function (item) { return !item.hasAttribute('hidden'); }).length; }
    function updateSiteGroups() {
      Array.prototype.slice.call(panel.querySelectorAll('[data-cm-srl-site-group]')).forEach(function (group) {
        var groupItems = Array.prototype.slice.call(group.querySelectorAll('[data-cm-srl-load-item]'));
        var hasVisible = groupItems.some(function (item) { return !item.hasAttribute('hidden'); });
        if (hasVisible) { group.removeAttribute('hidden'); } else { group.setAttribute('hidden', 'hidden'); }
      });
    }
    function updateButton() {
      var visible = shownCount();
      updateSiteGroups();
      if (items.length > visible) {
        wrap.removeAttribute('hidden');
        button.textContent = 'Load more (' + (items.length - visible) + ')';
      } else {
        wrap.setAttribute('hidden', 'hidden');
      }
    }

    items.forEach(function (item, index) { if (index >= initialItems) { item.setAttribute('hidden', 'hidden'); } else { item.removeAttribute('hidden'); } });
    button.addEventListener('click', function () {
      var visible = shownCount();
      items.slice(visible, visible + stepItems).forEach(function (item) { item.removeAttribute('hidden'); });
      updateButton();
    });
    updateButton();
  }

  document.querySelectorAll('[data-cm-srl-panel]').forEach(setupLoadMore);

  document.querySelectorAll('[data-cm-srl-tabs]').forEach(function (wrap) {
    var tabs = Array.prototype.slice.call(wrap.querySelectorAll('[data-cm-srl-tab]'));
    var panels = Array.prototype.slice.call(wrap.querySelectorAll('[data-cm-srl-panel]'));
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var target = tab.getAttribute('data-cm-srl-tab');
        tabs.forEach(function (item) {
          var active = item === tab;
          item.classList.toggle('is-active', active);
          item.setAttribute('aria-selected', active ? 'true' : 'false');
        });
        panels.forEach(function (panel) {
          var active = panel.getAttribute('data-cm-srl-panel') === target;
          panel.classList.toggle('is-active', active);
          if (active) { panel.removeAttribute('hidden'); } else { panel.setAttribute('hidden', 'hidden'); }
        });
      });
    });
  });
});
