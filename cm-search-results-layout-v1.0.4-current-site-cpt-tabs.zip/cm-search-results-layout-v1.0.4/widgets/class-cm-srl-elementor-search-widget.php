<?php
if (!defined('ABSPATH')) { exit; }

class CM_SRL_Elementor_Search_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'cm_search_results_layout'; }
    public function get_title() { return __('CM Results List', 'cm-search-results-layout'); }
    public function get_icon() { return 'eicon-post-list'; }
    public function get_categories() { return array('general'); }
    public function get_keywords() { return array('posts', 'results', 'cpt', 'query', 'Connor Moizer'); }
    public function get_style_depends() { return array('cm-srl-search-layout'); }

    protected function register_controls() {
        $post_type_options = function_exists('cm_srl_public_post_type_options') ? cm_srl_public_post_type_options() : array('post' => 'Posts', 'page' => 'Pages');

        $this->start_controls_section('query_section', array(
            'label' => __('Content', 'cm-search-results-layout'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ));

        $this->add_control('post_types', array(
            'label' => __('Content to display', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => $post_type_options,
            'default' => array('post', 'page'),
            'label_block' => true,
            'description' => __('Choose posts, pages, blogs, live blogs, portfolio items or any registered CPT.', 'cm-search-results-layout'),
        ));

        $this->add_control('posts_per_page', array(
            'label' => __('Number of results', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 10,
        ));

        $this->add_control('orderby', array(
            'label' => __('Order by', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'date',
            'options' => array(
                'date' => __('Date', 'cm-search-results-layout'),
                'title' => __('Title', 'cm-search-results-layout'),
                'menu_order' => __('Menu Order', 'cm-search-results-layout'),
                'modified' => __('Last Modified', 'cm-search-results-layout'),
                'rand' => __('Random', 'cm-search-results-layout'),
            ),
        ));

        $this->add_control('order', array(
            'label' => __('Order', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => array('DESC' => __('Descending', 'cm-search-results-layout'), 'ASC' => __('Ascending', 'cm-search-results-layout')),
        ));

        $this->add_control('offset', array(
            'label' => __('Offset', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'min' => 0,
            'default' => 0,
        ));

        $this->add_control('use_current_search', array(
            'label' => __('Filter by current search term', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Yes', 'cm-search-results-layout'),
            'label_off' => __('No', 'cm-search-results-layout'),
            'return_value' => 'yes',
            'default' => '',
            'description' => __('Useful when this widget is placed on a search results template. This does not output a search box.', 'cm-search-results-layout'),
        ));

        $this->add_control('search_term', array(
            'label' => __('Manual search term', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '',
            'label_block' => true,
            'condition' => array('use_current_search!' => 'yes'),
        ));

        $this->add_control('include_ids', array(
            'label' => __('Include by ID', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'placeholder' => '12, 34, 56',
            'label_block' => true,
        ));

        $this->add_control('exclude_ids', array(
            'label' => __('Exclude by ID', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'placeholder' => '12, 34, 56',
            'label_block' => true,
        ));

        $this->end_controls_section();

        $this->start_controls_section('display_section', array(
            'label' => __('Display', 'cm-search-results-layout'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ));

        foreach (array(
            'show_description' => __('Show description', 'cm-search-results-layout'),
            'show_date' => __('Show date and time', 'cm-search-results-layout'),
            'show_type' => __('Show content type', 'cm-search-results-layout'),
            'show_author' => __('Show author', 'cm-search-results-layout'),
        ) as $key => $label) {
            $this->add_control($key, array(
                'label' => $label,
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'cm-search-results-layout'),
                'label_off' => __('No', 'cm-search-results-layout'),
                'return_value' => 'yes',
                'default' => 'yes',
            ));
        }

        $this->add_control('enable_load_more', array(
            'label' => __('Load more button', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Yes', 'cm-search-results-layout'),
            'label_off' => __('No', 'cm-search-results-layout'),
            'return_value' => 'yes',
            'default' => 'yes',
            'description' => __('Shows 10 results first, then loads no more than 10 more results per click.', 'cm-search-results-layout'),
        ));

        $this->add_control('empty_text', array(
            'label' => __('Empty message', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('No results found.', 'cm-search-results-layout'),
            'label_block' => true,
        ));

        $this->end_controls_section();

        $this->start_controls_section('style_section', array(
            'label' => __('Style', 'cm-search-results-layout'),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        ));

        $this->add_control('link_colour', array(
            'label' => __('Title link colour', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => array('{{WRAPPER}} .cm-srl-result-title a' => 'color: {{VALUE}};'),
        ));

        $this->add_control('divider_colour', array(
            'label' => __('Divider colour', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => array('{{WRAPPER}} .cm-srl-result-item' => 'border-bottom-color: {{VALUE}};'),
        ));

        $this->add_responsive_control('content_width', array(
            'label' => __('Content max width', 'cm-search-results-layout'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => array('px'),
            'range' => array('px' => array('min' => 320, 'max' => 1800)),
            'default' => array('unit' => 'px', 'size' => 1440),
            'selectors' => array('{{WRAPPER}} .cm-srl-main' => 'max-width: {{SIZE}}{{UNIT}};'),
        ));

        $this->end_controls_section();
    }

    protected function render() {
        if (function_exists('cm_srl_render_elementor_results_only')) {
            cm_srl_render_elementor_results_only($this->get_settings_for_display());
        }
    }
}
