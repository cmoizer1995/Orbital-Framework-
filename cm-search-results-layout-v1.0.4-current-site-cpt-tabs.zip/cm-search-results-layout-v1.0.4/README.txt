CM Search Results Layout v1.0.4

Elementor widget included: CM Results List.

What this plugin does:
- Replaces the WordPress search results page with a clean title, date/time, content type, author and description layout.
- Adds CPT tabs so results can be filtered by Pages, Posts, Blog, Live Blog and any public custom post type.
- Keeps Load more support: 10 results first, then up to 10 more per click.
- Multisite safe: the normal search page now defaults to Current site only, so it only listens to the site the visitor is on.
- Optional multisite controls still allow All sites or a selected other site when needed.
- Reset clears the search field and returns the search page to Current site only mode.

1.0.4 - Added current-site-only default mode for multisite search and kept CPT tabs as the main filter so irrelevant network content is filtered out.
1.0.3 - Added Elementor widget load more support. The widget shows 10 results first and each Load more click reveals no more than 10 additional results.

Author: Connor Moizer
Website: https://connormoizer.com
