<?php
if (!defined('ABSPATH')) { exit; }
get_header();
cm_srl_render_search_layout(array(
    'title' => __('Search', 'cm-search-results-layout'),
    'show_title' => 'yes',
    'show_scope_controls' => 'yes',
    'show_search_form' => 'yes',
    'use_current_search' => 'yes',
));
get_footer();
