<?php
/**
 * Plugin Name: CM Search Results Layout
 * Description: Replaces the WordPress search results screen with a divider/title/meta/description layout, CPT tabs, reset, load more, and optional multisite search controls.
 * Version: 1.0.4
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Text Domain: cm-search-results-layout
 */

if (!defined('ABSPATH')) { exit; }

define('CM_SRL_VERSION', '1.0.4');
define('CM_SRL_FILE', __FILE__);
define('CM_SRL_DIR', plugin_dir_path(__FILE__));
define('CM_SRL_URL', plugin_dir_url(__FILE__));

add_filter('template_include', 'cm_srl_template_include', 99);
function cm_srl_template_include($template) {
    if (is_search() && !is_admin()) {
        $plugin_template = CM_SRL_DIR . 'templates/search-results.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }
    return $template;
}

add_action('wp_enqueue_scripts', 'cm_srl_enqueue_assets');
function cm_srl_enqueue_assets() {
    wp_register_style('cm-srl-search-layout', CM_SRL_URL . 'assets/css/search-layout.css', array(), CM_SRL_VERSION);
    wp_register_script('cm-srl-search-layout', CM_SRL_URL . 'assets/js/search-layout.js', array(), CM_SRL_VERSION, true);

    if (is_search()) {
        cm_srl_enqueue_frontend_assets();
    }
}

function cm_srl_enqueue_frontend_assets() {
    wp_enqueue_style('cm-srl-search-layout');
    wp_enqueue_script('cm-srl-search-layout');
}

function cm_srl_current_search_page_url() {
    $scheme = is_ssl() ? 'https://' : 'http://';
    $host = isset($_SERVER['HTTP_HOST']) ? wp_unslash($_SERVER['HTTP_HOST']) : '';
    $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    if ($host && $uri) {
        $path = strtok($uri, '?');
        return esc_url_raw($scheme . $host . ($path ? $path : '/'));
    }
    return esc_url_raw(home_url('/'));
}

function cm_srl_requested_scope() {
    if (!is_multisite()) { return 'single'; }
    $scope = isset($_GET['cm_srl_scope']) ? sanitize_key(wp_unslash($_GET['cm_srl_scope'])) : 'single';
    return in_array($scope, array('single', 'multi', 'site'), true) ? $scope : 'single';
}

function cm_srl_requested_site_id() {
    $site_id = isset($_GET['cm_srl_site']) ? absint($_GET['cm_srl_site']) : get_current_blog_id();
    return $site_id > 0 ? $site_id : get_current_blog_id();
}

function cm_srl_all_network_site_ids() {
    if (!is_multisite()) { return array(get_current_blog_id()); }
    $sites = get_sites(array('public' => 1, 'archived' => 0, 'deleted' => 0, 'spam' => 0, 'number' => 0, 'fields' => 'ids'));
    return !empty($sites) ? array_map('absint', $sites) : array(get_current_blog_id());
}

function cm_srl_available_sites($scope = '') {
    $scope = $scope ? $scope : cm_srl_requested_scope();
    if (!is_multisite() || $scope === 'single') { return array(get_current_blog_id()); }
    if ($scope === 'site') { return array(cm_srl_requested_site_id()); }
    return cm_srl_all_network_site_ids();
}

function cm_srl_site_label($blog_id) {
    if (is_multisite() && absint($blog_id) !== get_current_blog_id()) {
        switch_to_blog(absint($blog_id));
        $label = get_bloginfo('name');
        restore_current_blog();
    } else {
        $label = get_bloginfo('name');
    }
    $label = trim(wp_strip_all_tags($label));
    return $label !== '' ? $label : sprintf(__('Site %d', 'cm-search-results-layout'), absint($blog_id));
}

function cm_srl_searchable_post_types_for_current_site() {
    $types = get_post_types(array('public' => true, 'exclude_from_search' => false), 'objects');
    if (!isset($types['page'])) {
        $page = get_post_type_object('page');
        if ($page) { $types['page'] = $page; }
    }
    unset($types['attachment']);
    return $types;
}

function cm_srl_post_type_group($post_type, $object = null) {
    $normal = strtolower(str_replace(array('-', '_'), ' ', (string) $post_type));
    $label = ($object && !empty($object->labels->name)) ? $object->labels->name : ucwords($normal);
    $label_normal = strtolower($label);

    if ($post_type === 'page' || $normal === 'pages') { return array('key' => 'pages', 'label' => __('Pages', 'cm-search-results-layout')); }
    if (in_array($normal, array('post', 'posts'), true)) { return array('key' => 'posts', 'label' => __('Posts', 'cm-search-results-layout')); }
    if (in_array($normal, array('blog', 'blogs'), true) || in_array($label_normal, array('blog', 'blogs'), true)) { return array('key' => 'blog', 'label' => __('Blog', 'cm-search-results-layout')); }
    if (in_array($normal, array('live blog', 'live blogs', 'liveblog', 'liveblogs'), true) || in_array($label_normal, array('live blog', 'live blogs'), true)) { return array('key' => 'live_blog', 'label' => __('Live Blog', 'cm-search-results-layout')); }

    return array('key' => sanitize_key($post_type), 'label' => $label);
}

function cm_srl_collect_network_post_types($scope = '') {
    $collected = array();
    foreach (cm_srl_available_sites($scope) as $blog_id) {
        $switched = false;
        if (is_multisite() && absint($blog_id) !== get_current_blog_id()) { switch_to_blog(absint($blog_id)); $switched = true; }
        $site_label = cm_srl_site_label(get_current_blog_id());
        foreach (cm_srl_searchable_post_types_for_current_site() as $post_type => $object) {
            $group = cm_srl_post_type_group($post_type, $object);
            $key = $group['key'];
            if (!isset($collected[$key])) { $collected[$key] = array('label' => $group['label'], 'sites' => array()); }
            if (!isset($collected[$key]['sites'][absint($blog_id)])) { $collected[$key]['sites'][absint($blog_id)] = array('post_types' => array(), 'site_label' => $site_label); }
            $collected[$key]['sites'][absint($blog_id)]['post_types'][] = $post_type;
            $collected[$key]['sites'][absint($blog_id)]['post_types'] = array_values(array_unique($collected[$key]['sites'][absint($blog_id)]['post_types']));
        }
        if ($switched) { restore_current_blog(); }
    }
    uasort($collected, function($a, $b) {
        $order = array('Pages' => 1, 'Blog' => 2, 'Live Blog' => 3, 'Posts' => 4);
        $av = isset($order[$a['label']]) ? $order[$a['label']] : 99;
        $bv = isset($order[$b['label']]) ? $order[$b['label']] : 99;
        return $av === $bv ? strcasecmp($a['label'], $b['label']) : ($av - $bv);
    });
    return $collected;
}

function cm_srl_item_description($post_id) {
    $excerpt = trim(wp_strip_all_tags(get_the_excerpt($post_id)));
    if ($excerpt !== '') { return $excerpt; }
    $post = get_post($post_id);
    if (!$post) { return ''; }
    $content = trim(wp_strip_all_tags(strip_shortcodes($post->post_content)));
    return $content === '' ? '' : wp_trim_words($content, 34, '…');
}

function cm_srl_item_type_label($post_id) {
    $type = get_post_type($post_id);
    $object = $type ? get_post_type_object($type) : null;
    return ($object && !empty($object->labels->singular_name)) ? $object->labels->singular_name : __('Content', 'cm-search-results-layout');
}

function cm_srl_render_search_result_item($post_id, $site_label = '') {
    $title = get_the_title($post_id);
    if ($title === '') { $title = __('Untitled', 'cm-search-results-layout'); }
    $description = cm_srl_item_description($post_id);
    ?>
    <article id="post-<?php echo esc_attr($post_id); ?>" <?php post_class('cm-srl-result-item', $post_id); ?> data-cm-srl-load-item>
        <h2 class="cm-srl-result-title"><a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo esc_html($title); ?></a></h2>
        <div class="cm-srl-result-meta">
            <?php
            $meta = array(
                sprintf('%1$s %2$s', esc_html(get_the_date('', $post_id)), esc_html(get_the_time('', $post_id))),
                esc_html(cm_srl_item_type_label($post_id)),
            );
            if ($site_label !== '') { $meta[] = esc_html($site_label); }
            $meta[] = esc_html(get_the_author_meta('display_name', (int) get_post_field('post_author', $post_id)));
            echo wp_kses_post(implode(' <span aria-hidden="true">|</span> ', array_filter($meta)));
            ?>
        </div>
        <?php if ($description !== '') : ?><p class="cm-srl-result-description"><?php echo esc_html($description); ?></p><?php endif; ?>
    </article>
    <?php
}

function cm_srl_count_for_site_type($search_query, $blog_id, $site_type_data) {
    $switched = false;
    if (is_multisite() && absint($blog_id) !== get_current_blog_id()) { switch_to_blog(absint($blog_id)); $switched = true; }
    $args = array('post_type' => array_values(array_unique((array) $site_type_data['post_types'])), 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'ignore_sticky_posts' => true);
    if (trim($search_query) !== '') { $args['s'] = trim($search_query); }
    $query = new WP_Query($args);
    $count = absint($query->found_posts);
    wp_reset_postdata();
    if ($switched) { restore_current_blog(); }
    return $count;
}

function cm_srl_filter_empty_sites_for_type($search_query, $type_data) {
    foreach ($type_data['sites'] as $blog_id => $site_type_data) {
        $count = cm_srl_count_for_site_type($search_query, $blog_id, $site_type_data);
        if ($count < 1) { unset($type_data['sites'][$blog_id]); } else { $type_data['sites'][$blog_id]['count'] = $count; }
    }
    return $type_data;
}

function cm_srl_count_for_collected_type($search_query, $type_data) {
    $count = 0;
    foreach ($type_data['sites'] as $blog_id => $site_type_data) { $count += cm_srl_count_for_site_type($search_query, $blog_id, $site_type_data); }
    return $count;
}

function cm_srl_render_search_post_type_panel($search_query, $type_key, $type_data, $index, $scope = '') {
    $panel_id = 'cm-srl-tab-panel-' . sanitize_html_class($type_key);
    $found = false;
    ?>
    <section id="<?php echo esc_attr($panel_id); ?>" class="cm-srl-tab-panel<?php echo $index === 0 ? ' is-active' : ''; ?>" role="tabpanel" data-cm-srl-panel="<?php echo esc_attr($type_key); ?>" <?php echo $index === 0 ? '' : 'hidden'; ?>>
        <h2 class="cm-srl-tab-heading"><?php echo esc_html($type_data['label']); ?></h2>
        <?php foreach ($type_data['sites'] as $blog_id => $site_type_data) :
            $switched = false;
            if (is_multisite() && absint($blog_id) !== get_current_blog_id()) { switch_to_blog(absint($blog_id)); $switched = true; }
            $args = array('post_type' => array_values(array_unique((array) $site_type_data['post_types'])), 'post_status' => 'publish', 'posts_per_page' => -1, 'ignore_sticky_posts' => true, 'orderby' => 'date', 'order' => 'DESC');
            if (trim($search_query) !== '') { $args['s'] = trim($search_query); }
            $query = new WP_Query($args);
            if ($query->have_posts()) : $found = true; ?>
                <div class="cm-srl-site-group" data-cm-srl-site-group>
                    <?php if (is_multisite() && $scope !== 'single') : ?><h3 class="cm-srl-site-heading"><?php echo esc_html($site_type_data['site_label']); ?></h3><?php endif; ?>
                    <?php while ($query->have_posts()) : $query->the_post(); cm_srl_render_search_result_item(get_the_ID(), (is_multisite() && $scope !== 'single') ? $site_type_data['site_label'] : ''); endwhile; ?>
                </div>
            <?php endif;
            wp_reset_postdata();
            if ($switched) { restore_current_blog(); }
        endforeach;
        if (!$found) { echo '<p class="cm-srl-empty">' . esc_html__('No content found in this tab.', 'cm-search-results-layout') . '</p>'; }
        if ($found) : ?>
            <div class="cm-srl-load-more-wrap" data-cm-srl-load-more-wrap hidden>
                <button type="button" class="cm-srl-load-more" data-cm-srl-load-more><?php esc_html_e('Load more', 'cm-search-results-layout'); ?></button>
            </div>
        <?php endif; ?>
    </section>
    <?php
}

function cm_srl_render_results($search_query) {
    $scope = cm_srl_requested_scope();
    $post_types = cm_srl_collect_network_post_types($scope);
    $tabs = array();
    foreach ($post_types as $type_key => $type_data) {
        $type_data = cm_srl_filter_empty_sites_for_type($search_query, $type_data);
        $count = cm_srl_count_for_collected_type($search_query, $type_data);
        if ($count > 0 && !empty($type_data['sites'])) { $type_data['count'] = $count; $tabs[$type_key] = $type_data; }
    }
    if (empty($tabs)) { echo '<p class="cm-srl-empty">' . esc_html__('No searchable content was found.', 'cm-search-results-layout') . '</p>'; return; }
    ?>
    <div class="cm-srl-tabs" data-cm-srl-tabs>
        <div class="cm-srl-tab-list" role="tablist" aria-label="<?php esc_attr_e('Search result content types', 'cm-search-results-layout'); ?>">
            <?php $i = 0; foreach ($tabs as $type_key => $tab) : $tab_id = 'cm-srl-tab-' . sanitize_html_class($type_key); $panel_id = 'cm-srl-tab-panel-' . sanitize_html_class($type_key); ?>
                <button id="<?php echo esc_attr($tab_id); ?>" class="cm-srl-tab<?php echo $i === 0 ? ' is-active' : ''; ?>" type="button" role="tab" aria-selected="<?php echo $i === 0 ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr($panel_id); ?>" data-cm-srl-tab="<?php echo esc_attr($type_key); ?>">
                    <span><?php echo esc_html($tab['label']); ?></span><strong><?php echo esc_html(number_format_i18n($tab['count'])); ?></strong>
                </button>
            <?php $i++; endforeach; ?>
        </div>
        <div class="cm-srl-tab-panels">
            <?php $i = 0; foreach ($tabs as $type_key => $tab) : cm_srl_render_search_post_type_panel($search_query, $type_key, $tab, $i, $scope); $i++; endforeach; ?>
        </div>
    </div>
    <?php
}

function cm_srl_render_scope_controls($search_query = '') {
    if (!is_multisite()) { return; }
    $scope = cm_srl_requested_scope();
    $active_site = cm_srl_requested_site_id();
    $base_url = cm_srl_current_search_page_url();
    ?>
    <div class="cm-srl-scope-tabs" role="tablist" aria-label="<?php esc_attr_e('Search by site', 'cm-search-results-layout'); ?>">
        <a class="cm-srl-scope-tab<?php echo $scope === 'single' ? ' is-active' : ''; ?>" role="tab" href="<?php echo esc_url(add_query_arg(array('s' => $search_query, 'cm_srl_scope' => 'single'), $base_url)); ?>"><?php esc_html_e('Current site only', 'cm-search-results-layout'); ?></a>
        <a class="cm-srl-scope-tab<?php echo $scope === 'multi' ? ' is-active' : ''; ?>" role="tab" href="<?php echo esc_url(add_query_arg(array('s' => $search_query, 'cm_srl_scope' => 'multi'), $base_url)); ?>"><?php esc_html_e('All sites', 'cm-search-results-layout'); ?></a>
        <?php foreach (cm_srl_all_network_site_ids() as $blog_id) : ?>
            <?php if (absint($blog_id) === get_current_blog_id()) { continue; } ?>
            <a class="cm-srl-scope-tab<?php echo ($scope === 'site' && absint($active_site) === absint($blog_id)) ? ' is-active' : ''; ?>" role="tab" href="<?php echo esc_url(add_query_arg(array('s' => $search_query, 'cm_srl_scope' => 'site', 'cm_srl_site' => absint($blog_id)), $base_url)); ?>"><?php echo esc_html(cm_srl_site_label($blog_id)); ?></a>
        <?php endforeach; ?>
        <a class="cm-srl-scope-tab cm-srl-reset-tab" href="<?php echo esc_url(add_query_arg(array('cm_srl_scope' => 'single'), $base_url)); ?>"><?php esc_html_e('Reset', 'cm-search-results-layout'); ?></a>
    </div>
    <?php
}


function cm_srl_widget_search_query($settings = array()) {
    $settings = is_array($settings) ? $settings : array();
    if (!empty($settings['use_current_search'])) {
        return get_search_query(false);
    }
    if (isset($_GET['s'])) {
        return sanitize_text_field(wp_unslash($_GET['s']));
    }
    return '';
}

function cm_srl_render_search_layout($settings = array()) {
    $defaults = array(
        'title' => __('Search', 'cm-search-results-layout'),
        'show_title' => 'yes',
        'show_scope_controls' => 'yes',
        'show_search_form' => 'yes',
        'intro_text' => '',
        'use_current_search' => 'yes',
    );
    $settings = wp_parse_args((array) $settings, $defaults);
    $search_query = cm_srl_widget_search_query($settings);

    cm_srl_enqueue_frontend_assets();
    ?>
    <section class="cm-srl-shell cm-srl-elementor-shell">
        <main class="cm-srl-main" role="main">
            <?php if ($settings['show_title'] === 'yes' && trim((string) $settings['title']) !== '') : ?>
                <h1 class="cm-srl-page-title"><?php echo esc_html($settings['title']); ?></h1>
            <?php endif; ?>

            <?php if ($settings['show_scope_controls'] === 'yes') { cm_srl_render_scope_controls($search_query); } ?>

            <?php if ($settings['show_search_form'] === 'yes') : ?>
                <form role="search" method="get" class="cm-srl-form search-form" action="<?php echo esc_url(cm_srl_current_search_page_url()); ?>">
                    <label class="cm-srl-label">
                        <span class="screen-reader-text"><?php esc_html_e('Search for:', 'cm-search-results-layout'); ?></span>
                        <input type="search" class="cm-srl-field search-field" placeholder="<?php esc_attr_e('Search posts, pages, blogs and CPTs', 'cm-search-results-layout'); ?>" value="<?php echo esc_attr($search_query); ?>" name="s" />
                    </label>
                    <input type="hidden" name="cm_srl_scope" value="<?php echo esc_attr(cm_srl_requested_scope()); ?>" />
                    <?php if (cm_srl_requested_scope() === 'site') : ?><input type="hidden" name="cm_srl_site" value="<?php echo esc_attr(cm_srl_requested_site_id()); ?>" /><?php endif; ?>
                    <button type="submit" class="cm-srl-submit search-submit"><?php esc_html_e('Search', 'cm-search-results-layout'); ?></button>
                </form>
            <?php endif; ?>

            <p class="cm-srl-count-label">
                <?php if (trim((string) $settings['intro_text']) !== '') : ?>
                    <?php echo esc_html($settings['intro_text']); ?>
                <?php elseif ($search_query !== '') : ?>
                    <?php printf(wp_kses_post(__('Showing filtered results for: <strong>%s</strong>', 'cm-search-results-layout')), esc_html($search_query)); ?>
                <?php else : ?>
                    <?php esc_html_e('Current site only is the default. Choose a CPT tab below to browse pages, posts, blogs, live blogs and registered custom post types from this site, or use the search box to filter the tabs.', 'cm-search-results-layout'); ?>
                <?php endif; ?>
            </p>

            <?php cm_srl_render_results($search_query); ?>
        </main>
    </section>
    <?php
}


function cm_srl_public_post_type_options() {
    $types = get_post_types(array('public' => true), 'objects');
    $options = array();
    foreach ($types as $type => $object) {
        if (in_array($type, array('attachment', 'elementor_library'), true)) { continue; }
        $options[$type] = !empty($object->labels->name) ? $object->labels->name : $type;
    }
    return $options;
}

function cm_srl_parse_ids($value) {
    if (is_array($value)) { $raw = $value; } else { $raw = preg_split('/[\s,]+/', (string) $value); }
    $ids = array();
    foreach ((array) $raw as $item) {
        $id = absint($item);
        if ($id > 0) { $ids[] = $id; }
    }
    return array_values(array_unique($ids));
}

function cm_srl_render_elementor_results_only($settings = array()) {
    $defaults = array(
        'post_types' => array('post', 'page'),
        'posts_per_page' => 10,
        'orderby' => 'date',
        'order' => 'DESC',
        'offset' => 0,
        'search_term' => '',
        'use_current_search' => '',
        'include_ids' => '',
        'exclude_ids' => '',
        'show_description' => 'yes',
        'show_date' => 'yes',
        'show_type' => 'yes',
        'show_author' => 'yes',
        'empty_text' => __('No results found.', 'cm-search-results-layout'),
        'enable_load_more' => 'yes',
    );
    $settings = wp_parse_args((array) $settings, $defaults);

    $post_types = !empty($settings['post_types']) ? (array) $settings['post_types'] : array('post', 'page');
    $post_types = array_values(array_intersect($post_types, array_keys(cm_srl_public_post_type_options())));
    if (empty($post_types)) { $post_types = array('post', 'page'); }

    $args = array(
        'post_type' => $post_types,
        'post_status' => 'publish',
        'posts_per_page' => max(1, absint($settings['posts_per_page'])),
        'ignore_sticky_posts' => true,
        'orderby' => sanitize_key($settings['orderby']),
        'order' => strtoupper($settings['order']) === 'ASC' ? 'ASC' : 'DESC',
        'offset' => max(0, absint($settings['offset'])),
    );

    if ($settings['use_current_search'] === 'yes' && get_search_query(false) !== '') {
        $args['s'] = get_search_query(false);
    } elseif (trim((string) $settings['search_term']) !== '') {
        $args['s'] = sanitize_text_field($settings['search_term']);
    }

    $include_ids = cm_srl_parse_ids($settings['include_ids']);
    $exclude_ids = cm_srl_parse_ids($settings['exclude_ids']);
    if (!empty($include_ids)) { $args['post__in'] = $include_ids; $args['orderby'] = 'post__in'; }
    if (!empty($exclude_ids)) { $args['post__not_in'] = $exclude_ids; }

    cm_srl_enqueue_frontend_assets();
    $query = new WP_Query($args);
    ?>
    <section class="cm-srl-shell cm-srl-elementor-results-only">
        <main class="cm-srl-main">
            <div class="cm-srl-results-only-list" data-cm-srl-panel data-cm-srl-initial="10" data-cm-srl-step="10">
                <?php if ($query->have_posts()) : ?>
                    <?php while ($query->have_posts()) : $query->the_post();
                        cm_srl_render_configurable_result_item(get_the_ID(), $settings);
                    endwhile; ?>
                    <?php if (!empty($settings['enable_load_more']) && $settings['enable_load_more'] === 'yes') : ?>
                        <div class="cm-srl-load-more-wrap" data-cm-srl-load-more-wrap hidden>
                            <button type="button" class="cm-srl-load-more" data-cm-srl-load-more><?php esc_html_e('Load more', 'cm-search-results-layout'); ?></button>
                        </div>
                    <?php endif; ?>
                <?php else : ?>
                    <p class="cm-srl-empty"><?php echo esc_html($settings['empty_text']); ?></p>
                <?php endif; wp_reset_postdata(); ?>
            </div>
        </main>
    </section>
    <?php
}

function cm_srl_render_configurable_result_item($post_id, $settings = array()) {
    $title = get_the_title($post_id);
    if ($title === '') { $title = __('Untitled', 'cm-search-results-layout'); }
    $meta = array();
    if (!empty($settings['show_date']) && $settings['show_date'] === 'yes') {
        $meta[] = sprintf('%1$s %2$s', esc_html(get_the_date('', $post_id)), esc_html(get_the_time('', $post_id)));
    }
    if (!empty($settings['show_type']) && $settings['show_type'] === 'yes') {
        $meta[] = esc_html(cm_srl_item_type_label($post_id));
    }
    if (!empty($settings['show_author']) && $settings['show_author'] === 'yes') {
        $meta[] = esc_html(get_the_author_meta('display_name', (int) get_post_field('post_author', $post_id)));
    }
    $description = cm_srl_item_description($post_id);
    ?>
    <article id="post-<?php echo esc_attr($post_id); ?>" <?php post_class('cm-srl-result-item', $post_id); ?> data-cm-srl-load-item>
        <h2 class="cm-srl-result-title"><a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo esc_html($title); ?></a></h2>
        <?php if (!empty($meta)) : ?><div class="cm-srl-result-meta"><?php echo wp_kses_post(implode(' <span aria-hidden="true">|</span> ', array_filter($meta))); ?></div><?php endif; ?>
        <?php if (!empty($settings['show_description']) && $settings['show_description'] === 'yes' && $description !== '') : ?><p class="cm-srl-result-description"><?php echo esc_html($description); ?></p><?php endif; ?>
    </article>
    <?php
}

add_shortcode('cm_search_results_layout', function($atts) {
    $atts = shortcode_atts(array(
        'title' => __('Search', 'cm-search-results-layout'),
        'show_title' => 'yes',
        'show_scope_controls' => 'yes',
        'show_search_form' => 'yes',
        'intro_text' => '',
        'use_current_search' => 'yes',
    ), $atts, 'cm_search_results_layout');
    ob_start();
    cm_srl_render_search_layout($atts);
    return ob_get_clean();
});

add_action('elementor/widgets/register', 'cm_srl_register_elementor_widget');
add_action('elementor/widgets/widgets_registered', 'cm_srl_register_elementor_widget');
function cm_srl_register_elementor_widget($widgets_manager = null) {
    if (!did_action('elementor/loaded')) { return; }
    $widget_file = CM_SRL_DIR . 'widgets/class-cm-srl-elementor-search-widget.php';
    if (!file_exists($widget_file)) { return; }
    require_once $widget_file;
    if (!$widgets_manager && class_exists('Elementor\\Plugin')) {
        $widgets_manager = \Elementor\Plugin::instance()->widgets_manager;
    }
    if ($widgets_manager && class_exists('CM_SRL_Elementor_Search_Widget')) {
        if (method_exists($widgets_manager, 'register')) {
            $widgets_manager->register(new \CM_SRL_Elementor_Search_Widget());
        } elseif (method_exists($widgets_manager, 'register_widget_type')) {
            $widgets_manager->register_widget_type(new \CM_SRL_Elementor_Search_Widget());
        }
    }
}
